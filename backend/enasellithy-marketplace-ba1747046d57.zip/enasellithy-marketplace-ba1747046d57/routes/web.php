<?php

use Illuminate\Support\Facades\Route;

$namespace = "App\\Http\\Controllers\\";

Route::get('/', $namespace.'MyFatoorahController@index');

//ATBB8ZzraL3GAv6MXeUkLR9U8kuE291EDB51

Route::get('pay',[\App\Http\Controllers\Service\Payment\SadaPayController::class,'index']);
