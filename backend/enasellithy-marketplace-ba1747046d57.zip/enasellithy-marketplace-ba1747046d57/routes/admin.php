<?php

$namespace = 'App\\Http\\Controllers\\Admin\\';

Route::group(['prefix' => 'dashboard'], function () use ($namespace){

    Route::group(['middleware' => 'guest'], function () use ($namespace){
        Route::get('/login', $namespace . 'Auth\LoginController@login_view')->name('dashboard.login');
        Route::post('/login_post', $namespace . 'Auth\LoginController@login_post')->name('dashboard.login_post');
    });

    Route::group(['middleware' => ['auth'], 'namespace' => $namespace], function () use ($namespace) {

        Route::get('/profile', 'Auth\ProfileController@show')->name('dashboard.profile');
        Route::get('/logout', 'Auth\ProfileController@logout')->name('dashboard.logout');
        Route::post('/updateProfile', 'Auth\ProfileController@updateProfile')->name('dashboard.updateProfile');
        Route::get('/', 'HomeController@index')->name('dashboard.index');
        Route::get('user_search','UserController@user_search');
        Route::get('ads_search','AdsController@ads_search');
        Route::get('delete_image/{id}','MediaController@delete_image');

        Route::resource('plan', 'PlanController');
        Route::get('plan/delete/{id}','PlanController@delete');
        Route::get('plan/{id}/active','PlanController@active');
        Route::get('ads/{id}/active','AdsController@active');


        Route::group(['middleware' => ['checkpermission']], function ()  {
            Route::resource('faq', 'FAQController');
            Route::get('faq/delete/{id}','FAQController@delete');

            Route::resource('roles', 'RoleController');
            Route::get('roles/delete/{id}','RoleController@delete');

            Route::resource('setting', 'SettingController');

            Route::resource('faq', 'FAQController');
            Route::get('faq/delete/{id}','FAQController@delete');

            Route::resource('category', 'CategoryController');
            Route::get('category/delete/{id}','CategoryController@delete');

//            Route::resource('sub_category', 'SubCategoryController');
//            Route::get('sub_category/delete/{id}','SubCategoryController@delete');

            Route::resource('admin', 'AdminController');
            Route::get('admin/delete/{id}','AdminController@delete');

            Route::resource('users', 'UserController');
            Route::get('users/delete/{id}','UserController@delete');

            Route::resource('role', 'RoleController');
            Route::get('role/delete/{id}','RoleController@delete');

            Route::resource('permission', 'PermissionController')->only(['index','edit','update']);
            Route::get('permission/delete/{id}','PermissionController@delete');


            Route::resource('ads', 'AdsController');
            Route::get('ads/delete/{id}','AdsController@delete');

            Route::resource('banner', 'BannerController');
            Route::get('banner/delete/{id}','BannerController@delete');

            Route::resource('banner2', 'BannerTwoController');
            Route::get('banner2/delete/{id}','BannerTwoController@delete');

//            Route::resource('plan', 'PlanController');
//            Route::get('plan/delete/{id}','PlanController@delete');
//            Route::get('plan/{id}/active','PlanController@active');

            Route::resource('about', 'AboutController')->only(['index','store']);
            Route::resource('privacy', 'PrivacyController')->only(['index','store']);
            Route::resource('terms', 'TermsController')->only(['index','store']);
            Route::resource('contact', 'ContactController')->only(['index']);

        });

    });
});
