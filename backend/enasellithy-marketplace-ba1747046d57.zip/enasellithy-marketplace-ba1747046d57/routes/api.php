<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

$namespace = 'App\\Http\\Controllers\\API\\';
$payment = 'App\\Http\\Controllers\\API\\Payment\\';

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::group(['prefix' => 'V1'], function () use ($namespace, $payment){
    Route::get('faq', $namespace.'FAQController@index');
    Route::get('about', $namespace.'FAQController@about');
    Route::get('privacy', $namespace.'FAQController@privacy');
    Route::get('terms', $namespace.'FAQController@terms');
    Route::post('contact', $namespace.'FAQController@contact');

    Route::post('login', $namespace.'Auth\LoginController@login');
    Route::post('register', $namespace.'Auth\RegisterController@register');
    Route::post('resendCode', $namespace.'Auth\RegisterController@resendCode');
    Route::post('verifyCode', $namespace.'Auth\RegisterController@verifyCode');
    Route::post('resetPassword', $namespace.'Auth\ResetPasswordController@resetPassword');
    Route::post('updatePassword', $namespace.'Auth\ResetPasswordController@updatePassword');
    Route::resource('banner',$namespace.'BannerController');

    Route::get('banner2',$namespace.'BannerController@banner2');

    Route::get('home', $namespace.'HomeController@home');
    
    Route::resource('cats',$namespace.'CategoryController');

    Route::group(['middleware' => 'checkApi'], function () use ($namespace, $payment){
        Route::resource('ads',$namespace.'AdsController')->only(['index','show']);
        Route::post('ads_search',$namespace.'AdsController@ads_search');

        Route::get('getuser', $namespace.'Auth\ProfileController@getuser');
        Route::post('updateProfile', $namespace.'Auth\ProfileController@updateProfile');
        Route::get('logout', $namespace.'Auth\LoginController@logout');
        Route::get('deleteAccount', $namespace.'Auth\ProfileController@deleteAccount');
        Route::post('fav_ads',$namespace.'FavoutiatControlle@store');
        Route::get('get_fav_ads',$namespace.'FavoutiatControlle@index');
        Route::resource('ads',$namespace.'AdsController');
        Route::get('getMyAds', $namespace.'AdsController@getMyAds');
        //$namespace.'MyFatoorahController@index'

        Route::post('payment', $payment.'PaymentController@index');
    });
});

