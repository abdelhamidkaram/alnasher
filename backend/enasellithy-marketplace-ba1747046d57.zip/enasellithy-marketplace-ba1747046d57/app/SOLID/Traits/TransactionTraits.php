<?php

namespace App\SOLID\Traits;

use App\Models\Plan;
use App\Models\Transaction;
use App\Models\UserPlan;
use Illuminate\Support\Facades\DB;

trait TransactionTraits
{
    public function create(array $r)
    {
        DB::beginTransaction();

        try {
            $plan = Plan::find($r['plan_id']);
            $new = auth_api()->transaction()->create([
                'amount' => $plan->price,
                'plan_id' => $r['plan_id']
            ]);
            UserPlan::create([
                'user_id' => auth_api()->id,
                'plan_id' => $r['plan_id'],
            ]);
            return $new->id;
        }catch(\Exception $e)
        {
            DB::rollback();
            throw $e;
        }
        DB::commit();
    }
}
