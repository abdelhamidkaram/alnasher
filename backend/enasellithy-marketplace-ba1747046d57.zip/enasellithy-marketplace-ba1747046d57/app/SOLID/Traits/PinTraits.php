<?php


namespace App\SOLID\Traits;


use App\Models\PinCode;
use App\Models\User;

trait PinTraits
{
    use SMSTraits;
    public function GenerateCode($id)
    {
        $user = User::find($id); //
        $length = 4;
        $min = pow(10, $length - 1) ;
        $max = pow(10, $length) - 1;
        $rand =  mt_rand($min, $max);
        $code = PinCode::create([
            'user_id' => $id,
            'code' => $rand,
        ]);
        return $code->code;
    }

    public function getCode($user_id)
    {
        $check = PinCode::where('user_id',$user_id);
        if($check->count() != 0){
            return $check->firstOrFail();
        }else{
            return;
        }
    }

    public function updateCode($user_id,$code)
    {
        $item = PinCode::find($code);
        $item->check = $item->check + (int)1;
        $item->save();
        return;
    }

    public function generateQR($id)
    {
        $number = mt_rand(1000000000, 9999999999);
        $code = $number.$id;
        return $code;
    }
}
