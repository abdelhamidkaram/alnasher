<?php


namespace App\SOLID\Traits;


use App\Models\Media;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Intervention\Image\ImageManagerStatic as Image;

trait FileTraits
{
    public function uploadImage($file,$path, $renameFile = null)
    {
        if(!empty($file)){
            $filename = $renameFile .'.' . $file->extension();
            $savePath = public_path()."/".$path;
            if (!file_exists($savePath)) {
                mkdir($savePath , 0777, true);
            }
            $image_resize = Image::make($file->getRealPath());
            $image_resize->save($savePath.'/'.$filename);
            return $path.'/'.$filename;
        }
    }

    public function uploadImage_and_save($file,$path, $renameFile = null, $collection_name, $model_id,$model_name)
    {
        // name, type,model_name, model_id,path,collection_name
        if(!empty($file)){
            $filename = $renameFile .'.' . $file->extension();
            $savePath = public_path()."/".$path;
            if (!file_exists($savePath)) {
                mkdir($savePath , 0777, true);
            }
            $image_resize = Image::make($file->getRealPath());
            $image_resize->save($savePath.'/'.$filename);

            Media::create([
                'name' => $filename,
                'path' => $path.'/'.$filename,
                'collection_name' => $collection_name,
                'model_id' => $model_id,
                'model_name' => $model_name,
            ]);
            return;
        }
    }

    public function uploadVideo($file,$path, $renameFile = null)
    {
        if(!empty($file)) {
            $filename = $renameFile . '.' . $file->extension();
            $location = $file->move($path, $filename);
            return $path. '/' . $filename;
        }
    }

    public function uploadVideoAdmin($file,$path,$filename, $renameFile = null)
    {
        if(!empty($file)) {
            $location = $file->move($path, $filename);
            return $path . '/' . $filename;
        }
    }

    function is_base64_encoded(array $r)
    {
        $file = $r['file_name'];
        if(str_contains($file ,'data:image/')){
            $image_parts = explode(";base64,", $file);
            $image_type_aux = explode("image/", $image_parts[0]);
            $image_type = $image_type_aux[1];
            $image_base64 = base64_decode($image_parts[1]);
            $savePath = public_path()."/".'base64';
            $filename = time().'.'.$image_type;
            $image = file_put_contents(public_path()."/".'base64', $image_base64);
            return $image;
        }
    }

    public function storageCenter($file,$path)
    {
        $filename = time() . '.' . $file->getClientOriginalExtension();
        $location = $file->move($path, $filename);
        return $path. $filename;
    }

    public function uploadPDF($file,$path)
    {
        if(!empty($file)) {
            $savePath = 'files/' . Carbon::now('Y')->year;
            $filename = time() . '.' . $file->extension();
            $location = $file->move('files/' . Carbon::now('Y')->year . '/'.$path, $filename);
            return 'video/'. Carbon::now('Y')->year . '/'.$path . '/' . $filename;
        }
    }

    public function uploadHelper($file,$path)
    {
        if(!empty($file)){
            $filename = time() .'.' . $file->extension();
            $savePath = public_path()."/".$path;
            if (!file_exists($savePath)) {
                mkdir($savePath , 0777, true);
            }
            $image_resize = Image::make($file->getRealPath());
            $image_resize->save($savePath.'/'.$filename);
            return $path.'/'.$filename;
        }
    }
}
