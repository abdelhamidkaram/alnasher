<?php


namespace App\SOLID\Traits;


use GuzzleHttp\Client;

trait SMSTraits
{
    use JsonTrait;
    public function sms0($number,$msg)
    {
        $url = config('services.taqnyat_sms.base_url').'v1/messages';
        $token = config('services.taqnyat_sms.key');
        $sender = config('services.taqnyat_sms.sender');
//        $string = 'كلمة المرور المؤقتة هي ';
        //Your verification code: XXXX  For login taqnyat.sa portal
//        $string = $msg.' is your verification code.';
        $string = "Your verification code: ". $msg . " For login uad.com portal";
        $url = 'https://api.taqnyat.sa/v1/messages?sender='.$sender.'&recipients='.$number.'&body='.$string;
        $client = new Client();
        try{
            $response = $client->post($url,[
                'headers' => [
                    'content-type' => 'application/json',
                    'Authorization' => 'Bearer '.$token,
                ],
            ]);
            $json = json_decode($response->getBody());
            return $json;
        }catch (\GuzzleHttp\Exception\BadResponseException $e) {
            return $this->whenError('عذرا حدث خطأ ما
يرجى المحاولة في وقت لاحق');
        }

//        dd($response);
//        $json = json_decode($response->getBody());
//        if($response->getStatusCode() == 201){
//            return $this->whenDone('SMS sent');
//        }else{
//            return $this->whenError('Wrong');
//        }
    }
}
