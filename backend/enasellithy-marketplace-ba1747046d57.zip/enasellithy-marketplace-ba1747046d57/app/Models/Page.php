<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    use HasFactory;

    protected $table = 'pages';

    protected $guarded = [];

    public function scopeAbout($query){
        return $query->where('slug','about')->firstOrFail();
    }

    public function scopePrivacy($query){
        return $query->where('slug','privacy')->firstOrFail();
    }

    public function scopeTerms($query){
        return $query->where('slug','terms')->firstOrFail();
    }
}
