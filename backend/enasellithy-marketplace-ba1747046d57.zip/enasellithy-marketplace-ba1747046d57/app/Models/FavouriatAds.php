<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FavouriatAds extends Model
{
    use HasFactory;

    protected $table = 'favouriat_ads';

    protected $fillable = [
        'user_id',
        'ads_id',
    ];

    public function user(){
        return $this->belongsTo(User::class,'user_id');
    }

    public function ads(){
        return $this->belongsTo(Ads::class,'ads_id');
    }
}
