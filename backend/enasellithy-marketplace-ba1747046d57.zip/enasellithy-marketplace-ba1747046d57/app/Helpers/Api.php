<?php

if (!function_exists('AddZeroAtTheBegainingOfMobile')) {
    function AddZeroAtTheBegainingOfMobile($mobile) {
        if (substr($mobile, 0, 1) == 0) {
            $new_mobile = $mobile;
        } else {
            $new_mobile = "0" + $mobile;
        }
        return $new_mobile;
    }
}
