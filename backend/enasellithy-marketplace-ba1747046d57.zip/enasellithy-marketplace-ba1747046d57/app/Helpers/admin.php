<?php

use App\Models\Transaction;
use App\Models\User;

if (!function_exists('aurl')) {
    function aurl($url = null) {
        return url('dashboard/'.$url);
    }
}

if (!function_exists('active_link')) {
    function active_link($link)
    {
        if (request()->is($link)) {
            return 'active';
        }
    }
}

if (!function_exists('active_menu')) {
    function active_menu($link){
        if (request()->is($link)) {
            return 'active open';
            //return 'has-sub sidebar-group-active open';
        }
    }
}

if (!function_exists('sub_menu')) {
    function sub_menu($link){
        if (request()->is($link)) {
            return 'active open';
            //return 'has-sub sidebar-group-active open';
        }
    }
}

if (!function_exists('active_show')) {
    function active_show($link){
        if (request()->is($link)) {
            return 'active';
        }
    }
}

if (!function_exists('convert2english')) {
    function convert2english($string) {
        $newNumbers = range(0, 9);
        // 1. Persian HTML decimal
        $persianDecimal = array('&#1776;', '&#1777;', '&#1778;', '&#1779;', '&#1780;', '&#1781;', '&#1782;', '&#1783;', '&#1784;', '&#1785;');
        // 2. Arabic HTML decimal
        $arabicDecimal = array('&#1632;', '&#1633;', '&#1634;', '&#1635;', '&#1636;', '&#1637;', '&#1638;', '&#1639;', '&#1640;', '&#1641;');
        // 3. Arabic Numeric
        $arabic = array('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩');
        // 4. Persian Numeric
        $persian = array('۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹');

        $string =  str_replace($persianDecimal, $newNumbers, $string);
        $string =  str_replace($arabicDecimal, $newNumbers, $string);
        $string =  str_replace($arabic, $newNumbers, $string);
        return str_replace($persian, $newNumbers, $string);
    }
}

if (!function_exists('dateConvert')){
    function dateConvert($string) {
        return strtr($string, array('۰'=>'0', '۱'=>'1', '۲'=>'2', '۳'=>'3', '۴'=>'4', '۵'=>'5', '۶'=>'6', '۷'=>'7', '۸'=>'8', '۹'=>'9', '٠'=>'0', '١'=>'1', '٢'=>'2', '٣'=>'3', '٤'=>'4', '٥'=>'5', '٦'=>'6', '٧'=>'7', '٨'=>'8', '٩'=>'9'));
    }
}

if(!function_exists('filterElement')){
    function filterElement($type,$num=null){
        if($type == 'select'){

            $tag = '<select><option></option></select>';
            return strip_tags($tag);
        }
    }
}

if(!function_exists('vat')){
    function vat(){
        return \App\Models\Settings::find(1)->VAT;
    }
}

if(!function_exists('currency')){
    function currency(){
        return \App\Models\Settings::find(1)->currency;
    }
}

if(!function_exists('screen_list')){
    function screen_list(){
        return [
            'check_phone' => trans('screens.check_phone'),
            'check_pin_code' => trans('screens.check_pin_code'),
            'create_company_profile' => trans('screens.create_company_profile'),
            'add_brand' => trans('screens.add_brand'),
            'add_category' => trans('screens.add_category'),
            'add_platform' => trans('screens.add_platform'),
            'add_location' => trans('screens.add_location'),
            'create_profile' => trans('screens.create_profile'),
            'choose_langauge' => trans('screens.choose_langauge'),
            'contact_us' => trans('screens.contact_us'),
            'create_campaign' => trans('screens.create_campaign'),
            'campaign_type_ready' => trans('screens.campaign_type_ready'),
            'campaign_type_live' => trans('screens.campaign_type_live'),
            'campaign_settings' => trans('screens.campaign_settings'),
            'home' => trans('screens.home'),
        ];
    }
}

if(!function_exists('complaint_status')){
    function complaint_status(){
        return [
            'new' => trans('screens.new'),
            'current' => trans('screens.current'),
            'close' => trans('screens.close'),
        ];
    }
}

if(!function_exists('add_transaction')){
    function add_transaction(array $r){
        $data = User::find($r['inf_id']);
        $wallet = $data->wallet;
        $model = Transaction::create([
            'user_id' => $r['inf_id'],
            'amount' => $r['amount'],
            'convert_by' => auth()->user()->id,
            'transaction_status' => $r['amount'],
            'status' => 'Successful',
            'account_type' => 'influancer',
            'method_type' => $r['method_type'],

        ]);
        if($r['type'] == 'discount')
        {
            User::where('id',$r['inf_id'])->update([
                'wallet' => (int)$wallet - (int)$r['amount'],
            ]);
            $des = 'تم خصم مبلغ بمحفظتك';
        }
        else{
            User::where('id',$r['inf_id'])->update([
                'wallet' => (int)$wallet + (int)$r['amount'],
            ]);
            $des = 'تم اضافه مبلغ بمحفظتك';
//            $this->sendToUser($r->inf_id,$model->amount,$des);
        }
        return $model;
    }
}

if(!function_exists('user_percentage')){
    function user_percentage($type)
    {
        $percentage = \App\Models\User::whereHas('roles',function($q) use ($type){$q->where('name',$type);})->whereNull('archive')->count();
        $total = \App\Models\User::whereHas('roles',function($q){$q->whereIn('name',['Adv','influancer']);})->whereNull('archive')->count();

        $new = ($percentage / $total) * 100;

        return round($new,1);
    }
}

if(!function_exists('percentage_com')){
    function percentage_com()
    {
        $percentage = \App\Models\Campaign::where('status','completed')->count();
        $total = \App\Models\Campaign::count();

        $new = ($percentage / $total) * 100;

        return round($new,1);
    }
}

if(!function_exists('convert_k')){
    function convert_k($type)
    {
        if (strpos(strtoupper($type), "K") != false) {
            $s = rtrim($type, "kK");
            return floatval($type) * 1000;
        } else if (strpos(strtoupper($type), "M") != false) {
            $s = rtrim($type, "mM");
            return floatval($s) * 1000000;
        } else {
            return floatval($type);
        }
    }
}


if(!function_exists('phone_list')){
    function phone_list(){
        return [
            '012032980102'
        ];
    }
}

if (!function_exists('auth_api')) {
    function auth_api() {
        return Illuminate\Support\Facades\Auth::guard('api')->user();
    }
}

if (!function_exists('plan')) {
    function plan() {
        return [
            'يومى',
            'اسبوعى',
            'شهرى',
        ];
    }
}

if (!function_exists('plan_expire')) {
    function plan_expire($type) {
        $data = \App\Models\Plan::find($type);
        return Carbon\Carbon::now()->addDays($data->count);
    }
}
