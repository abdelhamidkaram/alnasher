<?php

use Intervention\Image\ImageManagerStatic as Image;

if (!function_exists('general_model')) {
    function general_model($field,$value,$model_name,$model_id) {
        $data = \App\Models\General::create([
            'field' => $field,
            'value' => $value,
            'model_name' => $model_name,
            'model_id' => $model_id
        ]);
    }
}
