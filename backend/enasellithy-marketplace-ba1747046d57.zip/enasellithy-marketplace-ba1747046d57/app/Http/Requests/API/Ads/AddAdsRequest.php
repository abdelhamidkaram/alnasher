<?php

namespace App\Http\Requests\API\Ads;

use App\SOLID\Traits\JsonTrait;
use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Http\Exceptions\HttpResponseException;

class AddAdsRequest extends FormRequest
{
    use JsonTrait;

    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title' => [
                'required',
                'string',
                'min:5',
                'max:255',
            ],
            'category_id' => [
                'required',
                'numeric',
                'exists:categories,id',
            ],
            'price' => [
                'required',
                'numeric',
            ],
            'phone' => [
                'required',
            ],
            'whatsapp' => [
                'required',
            ],
            'des' => [
                'required',
                'string',
                'min:5',
                'max:255',
            ],
        ];
    }

    protected function failedValidation(Validator $validator)
    {
        $err = $validator->errors()->first();
        throw new HttpResponseException($this->whenError($err));
    }
}
