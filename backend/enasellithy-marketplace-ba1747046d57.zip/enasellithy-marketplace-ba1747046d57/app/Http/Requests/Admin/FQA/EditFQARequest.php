<?php

namespace App\Http\Requests\Admin\FQA;

use Illuminate\Foundation\Http\FormRequest;

class EditFQARequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'slug' => 'required',
            'question' => 'required',
            'anwser' => 'required',
            'status' => 'required',
        ];
    }
}
