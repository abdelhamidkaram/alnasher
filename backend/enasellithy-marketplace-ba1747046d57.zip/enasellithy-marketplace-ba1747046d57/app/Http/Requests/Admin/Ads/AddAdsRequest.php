<?php

namespace App\Http\Requests\Admin\Ads;

use Illuminate\Foundation\Http\FormRequest;

class AddAdsRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'title' => [
                'required',
                'min:3',
                'max:255',
            ],
            'phone' => [
                'required',
            ],
            'whatsapp' => [
                'required',
            ],
            'des' => [
                'required',
                'min:3',
            ],
            'images' => [
                'required',
                'array',
            ],
            'category_id' => [
                'required'
            ],
            'user_id' => [
                'required'
            ],
        ];
    }
}
