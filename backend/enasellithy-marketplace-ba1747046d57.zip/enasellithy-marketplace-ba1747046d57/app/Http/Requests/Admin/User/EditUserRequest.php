<?php

namespace App\Http\Requests\Admin\User;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class EditUserRequest extends FormRequest
{
    public function authorize()
    {
        return true;
    }

    public function rules()
    {
        return [
            'name' => [
                'required',
            ],
            'email' => [
                'required',
                'email',
//                Rule::unique('users')->ignore($this->user),
            ],
            'password' => [
                'required',
            ],
            'role_id' => [
                'required',
                'numeric',
                'exists:roles,id'
            ]
        ];
    }
}
