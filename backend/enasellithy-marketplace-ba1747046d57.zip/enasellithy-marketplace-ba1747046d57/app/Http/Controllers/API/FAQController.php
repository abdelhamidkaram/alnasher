<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\API\FAQResource;
use App\Models\Contact;
use App\Models\FAQ;
use App\Models\Page;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class FAQController extends Controller
{
    use JsonTrait;

    public function index()
    {
        $list = FAQResource::collection(FAQ::latest()->paginate(20));
        $data['faq'] = $list->response()->getData();
        return $this->whenDone($data);
    }

    public function privacy()
    {
        $data['privacy'] = new FAQResource(Page::privacy());
        return $this->whenDone($data);
    }

    public function terms()
    {
        $data['terms'] = new FAQResource(Page::terms());
        return $this->whenDone($data);
    }

    public function about()
    {
        $data['about'] = new FAQResource(Page::about());
        return $this->whenDone($data);
    }

    public function contact(Request $r)
    {
        Contact::create($r->all());
        return $this->whenDone('');
    }
}
