<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\FavouriatAds\AddFavouriatAdsRequest;
use App\Http\Resources\API\AdsResource;
use App\Models\Ads;
use App\Models\FavouriatAds;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class FavoutiatControlle extends Controller
{
    use JsonTrait;

    public function index()
    {
        $list = FavouriatAds::where('user_id',auth_api()->id)->select('ads_id')->get();
        $item = AdsResource::collection(Ads::whereIn('id',$list)->latest()->paginate(20));
        $data['fav'] = $item->response()->getData();
        return $this->whenDone($data);
    }

    public function store(AddFavouriatAdsRequest $r)
    {
        $check = FavouriatAds::where('user_id',auth_api()->id)->where('ads_id',$r->ads_id)->count();
        if($check == 0){
            FavouriatAds::create(['user_id' => auth_api()->id, 'ads_id' => $r->ads_id]);
            $data['ads'] = new AdsResource(Ads::find($r->ads_id));
            return $this->whenDone($data);
        }
        else{
            $id = FavouriatAds::where('user_id',auth_api()->id)->where('ads_id',$r->ads_id)->first();
            $id->delete();
            $data['ads'] = new AdsResource(Ads::find($r->ads_id));
            return $this->whenDone($data,'success');
        }
    }
}
