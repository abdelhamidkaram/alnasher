<?php

namespace App\Http\Controllers\API\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\Auth\LoginRequest;
use App\Http\Requests\API\Auth\ResetPasswordRequest;
use App\Http\Requests\API\Auth\UpdatePasswordRequest;
use App\Http\Resources\API\UserResource;
use App\Mail\ResetPasswordEmail;
use App\Mail\SendCodeMail;
use App\Models\User;
use App\SOLID\Traits\JsonTrait;
use App\SOLID\Traits\PinTraits;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;

class ResetPasswordController extends Controller
{
    use JsonTrait, PinTraits;

    public function resetPassword(ResetPasswordRequest $r)
    {
        $user = User::where('email',$r->email);
        if($user->count() == 0){
            return $this->whenError('','اﻻيميل غير موجود');
        }else{
            $data = $this->GenerateCode($user->first()->id);
            Mail::to($user->first()->email)->send(new ResetPasswordEmail($data));
            return $this->whenDone('','done');
        }
    }

    public function updatePassword(UpdatePasswordRequest $r)
    {
        $user = User::where('email',$r->email);
        $userId = $user->firstOrFail()->id;
        $data = User::find($userId);
        $data->password = $r->password;
        $data->save();
//        User::where('id', $userId)->update([
//            'password' => $r->password,
//        ]);
        return $this->whenDone('','done');
    }
}
