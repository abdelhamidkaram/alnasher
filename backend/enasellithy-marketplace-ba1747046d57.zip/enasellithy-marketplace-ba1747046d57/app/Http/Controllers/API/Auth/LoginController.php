<?php

namespace App\Http\Controllers\API\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\Auth\LoginRequest;
use App\Http\Resources\API\UserResource;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    use JsonTrait;

    public function login(LoginRequest $r)
    {
//        dd($r->all(),Auth::attempt(['email' => $r->email, 'password' => $r->password]));
        if(Auth::attempt(['email' => $r->email, 'password' => $r->password])){
            $user = Auth::user();
            if($user->email_verified_at == null){
                return $this->whenError('برجاء تفعيل اﻻيميل');
            }
            else{
                $data['token'] =  'Bearer '.$user->createToken('MyApp')->plainTextToken;
                $data['user'] =  new UserResource(auth_api());
                return $this->whenDone($data);
            }
        }
        else{
            return $this->whenError('حدث خطأ ما .. برجاء المحاولة لاحقا','حدث خطأ ما .. برجاء المحاولة لاحقا');
        }
    }

    public function logout()
    {
        auth_api()->tokens()->delete();
        return $this->whenDone('Logout Done');
    }
}
