<?php

namespace App\Http\Controllers\API\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\Auth\UpdateProfileRequest;
use App\Http\Resources\API\AdsResource;
use App\Http\Resources\API\PlanResource;
use App\Http\Resources\API\UserResource;
use App\Models\Ads;
use App\Models\FavouriatAds;
use App\Models\Plan;
use App\Models\User;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    use JsonTrait;

    public function getuser(){
        $idList = FavouriatAds::where('user_id',auth_api()->id)->select('id')->get();
        $data['user'] = new UserResource(auth_api());
        $data['fav_list'] = AdsResource::collection(Ads::whereIn('id',$idList)->latest()->get());
        $data['current_plan'] = new PlanResource(Plan::find(auth_api()->plan_id));
        return $this->whenDone($data);
    }

    public function updateProfile(UpdateProfileRequest $r)
    {
        User::where('id', auth_api()->id)->update($r->all());
        $data['user'] = new UserResource(auth_api());
        return $this->whenDone($data);
    }

    public function deleteAccount()
    {
        User::find(auth_api()->id)->delete();
        auth_api()->tokens()->delete();
        return $this->whenDone('Account Deleted');
    }
}
