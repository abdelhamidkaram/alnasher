<?php

namespace App\Http\Controllers\API\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\Auth\RegisterRequest;
use App\Http\Requests\API\Auth\ResendRequest;
use App\Http\Requests\API\Auth\VerifyCodeRequest;
use App\Http\Resources\API\UserResource;
use App\Mail\SendCodeMail;
use App\Models\PinCode;
use App\Models\User;
use App\Models\UserPlan;
use App\SOLID\Traits\JsonTrait;
use App\SOLID\Traits\PinTraits;
use Carbon\Carbon;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Spatie\Permission\Models\Role;
use Illuminate\Http\Request;

class RegisterController extends Controller
{
    use JsonTrait, PinTraits;

    public function register(RegisterRequest $r)
    {
        $role = Role::findByName('User');
        $user = User::create($r->all());
        $user->update(['plan_id' => 1]);
        UserPlan::create([
            'user_id' => $user->id,
            'plan_id' => 1,
            'amount' => 0,
        ]);
        $user->syncRoles($role);
        $data = $this->GenerateCode($user->id);
        Mail::to($user->email)->send(new SendCodeMail($data));
        return $this->whenDone('','done');
    }

    public function resendCode(ResendRequest $r)
    {
        $user = User::where('email',$r->email)->firstOrFail();
        $this->GenerateCode($user->id);
        return $this->whenDone('','done');
    }

    public function verifyCode(VerifyCodeRequest $r)
    {
        $user = User::where('email',$r->email);
        if($user->count() == 0){
            return $this->whenError('','اﻻيميل غير موجود');
        }
        else{
            $userId = $user->first()->id;

            if(PinCode::where('code',$r->code)->where('check',0)->where('user_id',$userId)->count() != 0) {
                $code = PinCode::where('code',$r->code)->where('user_id',$userId)->where('check',0)->first();
                User::where('id',$userId)->update([
                    'email_verified_at' => Carbon::now(),
                ]);
                PinCode::where('code',$r->code)->where('user_id',$userId)->update(['check' => 1]);
                if(Auth::loginUsingId($userId)){
                    $data['user'] = new UserResource(User::find($userId));
                    $data['token'] = 'Bearer '.User::find($userId)->createToken('secrettoken')->plainTextToken;
                    return $this->whenDone($data);
                }
                return $this->whenDone('','done');
            }
            else{
               return $this->whenError('لا يوجد كود تفعيل');
            }
        }
    }
}
