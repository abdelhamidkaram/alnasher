<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\API\AdsResource;
use App\Http\Resources\API\BannerResource;
use App\Http\Resources\API\CategoryResource;
use App\Http\Resources\API\UserResource;
use App\Models\Ads;
use App\Models\Banner;
use App\Models\Category;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    use JsonTrait;

    public function home()
    {
//        $data['user'] = new UserResource(auth_api());
        $data['banner'] = BannerResource::collection(Banner::latest()->where('des','banner1')->get());
        $data['category'] = CategoryResource::collection(Category::whereNull('parent_id')->with('ads')->has('ads')->get());
        $data['ads'] = AdsResource::collection(Ads::latest()->with(['user','cats'])->paginate(20));
        return $this->whenDone($data);
    }
}
