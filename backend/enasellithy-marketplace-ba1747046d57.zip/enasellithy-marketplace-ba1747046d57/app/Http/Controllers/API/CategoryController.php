<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\API\CategoryResource;
use App\Http\Resources\API\SubCategoryResource;
use App\Models\Category;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class CategoryController extends Controller
{
    use JsonTrait;

    public function index()
    {
        $data = CategoryResource::collection(Category::get());
        return $this->whenDone($data);
    }

    public function show($id)
    {
        $data = new CategoryResource(Category::find($id));
        return $this->whenDone($data);
    }

    public function subCategory()
    {
        $data = SubCategoryResource::collection(Category::whereNotNull('parent_id')->get());
        return $this->whenDone($data);
    }
}
