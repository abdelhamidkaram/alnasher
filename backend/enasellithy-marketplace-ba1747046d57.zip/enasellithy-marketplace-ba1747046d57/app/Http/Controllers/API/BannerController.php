<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Resources\API\BannerResource;
use App\Models\Banner;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class BannerController extends Controller
{
    use JsonTrait;

    public function index()
    {
        $data['banner'] = BannerResource::collection(Banner::latest()->take(3)->get());
        return $this->whenDone($data);
    }

    public function banner2()
    {
        $data['banner'] = BannerResource::collection(Banner::where('des','banner2')->latest()->take(3)->get());
        return $this->whenDone($data);
    }
}
