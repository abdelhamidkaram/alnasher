<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Requests\API\Ads\AddAdsRequest;
use App\Http\Resources\API\AdsResource;
use App\Models\Ads;
use App\Models\Plan;
use App\Models\User;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\JsonTrait;
use Illuminate\Http\Request;

class AdsController extends Controller
{
    use JsonTrait, FileTraits;

    public function index()
    {
        $ads = AdsResource::collection(Ads::latest()->with(['user','cats'])->paginate(20));
        $data = $ads->response()->getData();
        return $this->whenDone($data);
    }

    public function ads_search(Request $r)
    {
        $category_id = $r->category_id;
        $title = $r->title;
        $query = Ads::latest()->with(['user','cats'])->when($title,function ($q) use ($title){
            $q->where('title', 'LIKE', '%'.$title.'%');
        })->when($category_id, function ($q) use ($category_id) {
            $q->where('category_id',$category_id);
        })->paginate(10);
        $ads = AdsResource::collection($query);
        $data = $ads->response()->getData();
        return $this->whenDone($data);
    }

    public function getMyAds()
    {
        $ads = AdsResource::collection(Ads::where('user_id',auth_api()->id)->latest()->with(['user','cats'])->paginate(20));
        $data = $ads->response()->getData();
        return $this->whenDone($data);
    }

    public function store(AddAdsRequest $r)
    {
        $ads = auth_api()->ads()->create($r->except('images1','images2','images3','images4','images5'));
        $ads->update([
            'expire_at' => plan_expire(auth_api()->plan_id),
            'active' => 'no',
        ]);
        $userPlan = Plan::find(auth_api()->plan_id);
        if($r->images1){
            $renameFile = time().'_'.$r->images1->extension();
            $this->uploadImage_and_save($r->images1,'uploads/ads/'.$ads->id,
                $renameFile,'ads_image',$ads->id, Ads::class);
        }
        if($r->images2){
            $renameFile = time().'_'.$r->images2->extension();
            $this->uploadImage_and_save($r->images2,'uploads/ads/'.$ads->id,
                $renameFile,'ads_image',$ads->id, Ads::class);
        }
        if($r->images3){
            $renameFile = time().'_'.$r->images3->extension();
            $this->uploadImage_and_save($r->images3,'uploads/ads/'.$ads->id,
                $renameFile,'ads_image',$ads->id, Ads::class);
        }
        if($r->images4){
            $renameFile = time().'_'.$r->images4->extension();
            $this->uploadImage_and_save($r->images4,'uploads/ads/'.$ads->id,
                $renameFile,'ads_image',$ads->id, Ads::class);
        }
        if($r->images5){
            $renameFile = time().'_'.$r->images5->extension();
            $this->uploadImage_and_save($r->images5,'uploads/ads/'.$ads->id,
                $renameFile,'ads_image',$ads->id, Ads::class);
        }
//        if(is_array($r->images)){
//            foreach($r->images as $i){
//                $renameFile = time().'_'.$i->extension();
//                $this->uploadImage_and_save($i,'uploads/ads/'.$ads->id,
//                    $renameFile,'ads_image',$ads->id, Ads::class);
//            }
//        }
        $data['ads'] = new AdsResource($ads);
        return $this->whenDone($data);
    }
}
