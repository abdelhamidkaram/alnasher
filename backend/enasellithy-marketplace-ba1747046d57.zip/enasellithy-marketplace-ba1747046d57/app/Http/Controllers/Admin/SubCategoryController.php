<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Category\AddCategoryRequest;
use App\Models\Category;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;

class SubCategoryController extends Controller
{
    use MessageTraits, FileTraits;

    public function index()
    {
        $data = Category::whereNotNull('parent_id')->latest()->paginate(10);
        return view('admin.sub_category.index', compact('data'));
    }

    public function store(AddCategoryRequest $r)
    {
        $data = Category::create($r->all());
        if($r->image){
            $path = "uploads/category/".$data->id."/";
            $name = $data->id.'_'.time();
            $data->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $this->done();
        return back();
    }

    public function update($id, Request $r)
    {
        $r->validate([
            'name' => 'required|max:25|unique:categories,name,'.$id,
        ]);
        $data = Category::where('id',$id)->update($r->except('_token','_method', 'image'));
        if($r->image){
            if(\File::exists(Category::find($id)->image)){
                unlink(public_path(Category::find($id)->image));
            }
            $path = "uploads/category/".$id."/";
            $name = $id.'_'.time();
            Category::where('id',$id)->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $this->done();
        return back();
    }

    public function delete($id)
    {
        Category::find($id)->delete();
        $this->done();
        return back();
    }
}
