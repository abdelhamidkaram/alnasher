<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Banner\AddBannerRequest;
use App\Http\Requests\Admin\Banner\EditBannerRequest;
use App\Models\Banner;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;

class BannerController extends Controller
{
    use MessageTraits, FileTraits;

    public function index()
    {
        $data = Banner::where('des','banner1')->latest()->paginate(10);
        return view('admin.banner.index', compact('data'));
    }

    public function store(AddBannerRequest $r)
    {
        $data = Banner::create($r->all());
        if($r->image){
            $path = "uploads/banner/".$data->id."/";
            $name = $data->id.'_'.time();
            $data->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
                'des' => 'banner1',
            ]);
        }
        $this->done();
        return back();
    }

    public function update($id, EditBannerRequest $r)
    {
        $data = Banner::where('id',$id)->update($r->except('_token','_method'));
        if($r->image){
            // if(\File::exists(Banner::find($id)->image)){
            //     unlink(public_path(Banner::find($id)->image));
            // }
            $path = "uploads/banner/".$id."/";
            $name = $id.'_'.time();
            Banner::where('id',$id)->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
                'des' => 'banner1',
            ]);
        }
        $this->done();
        return back();
    }

    public function delete($id)
    {
        if(\File::exists(Banner::find($id)->image)){
            unlink(public_path(Banner::find($id)->image));
        }
        Banner::find($id)->delete();
        $this->done();
        return back();
    }
}
