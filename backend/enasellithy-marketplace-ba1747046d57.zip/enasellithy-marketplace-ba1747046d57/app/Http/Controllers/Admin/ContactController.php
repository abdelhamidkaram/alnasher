<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use App\Models\Page;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use function Symfony\Component\String\b;

class ContactController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = Contact::latest()->paginate(50);
        return view('admin.contact.index', compact('data'));
    }
}
