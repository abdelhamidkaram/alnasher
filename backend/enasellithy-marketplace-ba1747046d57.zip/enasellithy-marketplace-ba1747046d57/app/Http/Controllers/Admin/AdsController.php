<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Ads\AddAdsRequest;
use App\Models\Ads;
use App\Models\Category;
use App\Models\FavouriatAds;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;

class AdsController extends Controller
{
    use MessageTraits, FileTraits;
    public function index()
    {
        $title = request()->title;
        $userId = request()->user_id;
        $category_id = request()->category_id;
        $data = Ads::latest()->with(['user','cats'])->paginate(10);
        return view('admin.ads.index', compact('data', 'title', 'userId', 'category_id'));
    }

    public function ads_search()
    {
        $title = request()->title;
        $userId = request()->user_id;
        $category_id = request()->category_id;
        $data = Ads::latest()->with(['user','cats'])
            ->when(!empty($userId), function ($q) use ($userId){
                $q->where('user_id',request()->user_id);
            })
            ->when(!empty($category_id), function ($q) use ($category_id){
                $q->where('category_id',$category_id);
            })
            ->where('title', 'LIKE', '%'.$title.'%')->paginate(10);
        return view('admin.ads.index', compact('data', 'title', 'userId', 'category_id'));
    }

    public function create()
    {
        $data = Category::latest()->get();
        return view('admin.ads.create', compact('data'));
    }

    public function store(AddAdsRequest $r)
    {
        $ads = Ads::create($r->except('images'));
        if(is_array($r->images)){
            foreach($r->images as $i){
                $renameFile = time().'_'.$i->extension();
                $this->uploadImage_and_save($i,'uploads/ads/'.$ads->id,
                    $renameFile,'ads_image',$ads->id, Ads::class);
            }
        }
        $this->done();
        return redirect(aurl('ads'));
    }

    public function show($id)
    {
        $data = Ads::find($id);
        return view('admin.ads.show', compact('data'));
    }

    public function edit($id)
    {
        $data = Ads::find($id);
        return view('admin.ads.edit', compact('data'));
    }

    public function update($id, Request $r)
    {
        $ads = Ads::where('id',$id)->update($r->except('images','_token','_method'));
        if(is_array($r->images)){
            foreach($r->images as $i){
                $renameFile = time().'_'.$i->extension();
                $this->uploadImage_and_save($i,'uploads/ads/'.$id,
                    $renameFile,'ads_image',$id, Ads::class);
            }
        }
        $this->done();
        return redirect(aurl('ads'));
    }

    public function delete($id)
    {
        Ads::find($id)->delete();
        $this->done();
        return back();
    }

    public function active($id)
    {
        $data = Ads::find($id);
        Ads::where('id',$id)->update([
            'active' => $data->active == 'no' ? 'yes' : 'no'
        ]);
        $this->done();
        return back();
    }
}
