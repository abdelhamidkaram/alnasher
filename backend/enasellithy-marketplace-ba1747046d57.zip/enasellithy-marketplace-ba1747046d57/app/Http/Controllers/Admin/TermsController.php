<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use function Symfony\Component\String\b;

class TermsController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = Page::terms();
        return view('admin.terms.index', compact('data'));
    }

    public function store(Request $r)
    {
        $data = Page::terms()->update($r->all());
        $this->done();
        return back();
    }
}
