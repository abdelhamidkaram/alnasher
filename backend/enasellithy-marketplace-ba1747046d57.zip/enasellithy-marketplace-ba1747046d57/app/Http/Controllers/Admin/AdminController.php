<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Admin\AddAdminRequest;
use App\Http\Requests\Admin\Admin\EditAdminRequest;
use App\Models\User;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class AdminController extends Controller
{
    use MessageTraits, FileTraits;

    public function index()
    {
        $data = User::whereHas('roles',function ($q){
            $q->where('name','!=','user');
        })->latest()->paginate(10);
        return view('admin.admin.index', compact('data'));
    }

    public function store(AddAdminRequest $r)
    {
//        dd($r->all());
        $role = Role::find($r->role_id);
        $user = User::create($r->except('image'));
        if($r->image){
            $path = "uploads/admins/".$user->id."/";
            $name = $user->id.'_'.time();
            User::where('id',$user->id)->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $user->syncRoles($role);
        $this->done();
        return back();
    }

    public function update($id,EditAdminRequest $r)
    {
        $role = Role::find($r->role_id);
        DB::table('model_has_roles')->where('model_id',$id)->delete();
        DB::table('model_has_roles')->insert([
            'model_id' => $id,
            'role_id' => $role->id,
            'model_type' => User::class,
        ]);
        $user = User::where('id',$id)->update($r->except('_token','_method','role_id'));
        if($r->image){
//            if(\File::exists(User::find($id)->image)){
//                unlink(public_path(User::find($id)->image));
//            }
            $path = "uploads/admins/".$id."/";
            $name = $id.'_'.time();
            User::where('id',$id)->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $this->done();
        return back();
    }

    public function delete($id)
    {
//        if(\File::exists(User::find($id)->image)){
//            unlink(public_path(User::find($id)->image));
//        }
        User::find($id)->delete();
        $this->done();
        return back();
    }
}
