<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Permission\AddPermissionRequest;
use App\Http\Requests\Admin\Permission\EditPermissionRequest;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use function Symfony\Component\String\b;

class PermissionController extends Controller
{
    use MessageTraits;

    public function index()
    {
//        dd(Permission::all()->pluck('id','name'));
        $data = Permission::latest()->paginate(10);
        return view('admin.permission.index', compact('data'));
    }

    public function store(AddPermissionRequest $r)
    {
        Permission::create($r->all());
        $this->done();
        return back();
    }

    public function update($id, EditPermissionRequest $r)
    {
        Permission::where('id',$id)->update($r->only('name'));
        $this->done();
        return back();
    }

    public function delete($id)
    {
        Permission::find($id)->delete();
        $this->done();
        return back();
    }
}
