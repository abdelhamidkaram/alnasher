<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Plan;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use function Symfony\Component\String\b;

class PlanController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = Plan::latest()->paginate(10);
        return view('admin.plan.index', compact('data'));
    }

    public function store(Request $r)
    {
        Plan::create($r->all());
        $this->done();
        return back();
    }

    public function update($id, Request $r)
    {
        Plan::where('id',$id)->update($r->except('_token','_method'));
        $this->done();
        return back();
    }

    public function delete($id)
    {
        Plan::find($id)->delete();
        $this->done();
        return back();
    }

    public function active($id)
    {
        $data = Plan::find($id);
        $data->status == 'no' ?  Plan::where('id', $id)->update(['status' => 'yes']) : Plan::where('id', $id)->update(['status' => 'no']);
        $this->done();
        return back();
    }
}
