<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\FavouriatAds;
use Illuminate\Http\Request;

class FavouriatAdsController extends Controller
{
    public function index()
    {
        $data = FavouriatAds::with(['user','ads'])->latest()->paginate(10);
        return view('admin.fav_ads.index', compact('data'));
    }
}
