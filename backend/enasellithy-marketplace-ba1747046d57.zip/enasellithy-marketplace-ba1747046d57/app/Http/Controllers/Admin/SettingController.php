<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Settings;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    use MessageTraits, FileTraits;

    public function index()
    {
        $data = Settings::find(1);
        return view('admin.settings.index', compact('data'));
    }

    public function store(Request $r)
    {
        Settings::find(1)->update($r->except('_token','_method','logo'));
        if($r->logo){
            if(\File::exists(Settings::find(1)->logo)){
                unlink(public_path(Settings::find(1)->logo));
            }
            $path = "uploads/setting/";
            $name = time();
            Settings::find(1)->update([
                'logo' => $this->uploadImage($r['logo'],$path,$name),
            ]);
        }
        $this->done();
        return back();
    }
}
