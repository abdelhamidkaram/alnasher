<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ads;
use App\Models\User;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function index()
    {
        $data = Ads::latest()->paginate(10);
//        dd($data);
        return view('admin.dashboard.index',compact('data'));
    }
}
