<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\FAQ\AddFAQRequest;
use App\Http\Requests\Admin\FAQ\EditFAQRequest;
use App\Models\FAQ;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;

class FAQController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = FAQ::latest()->paginate(10);
        return view('admin.faq.index', compact('data'));
    }

    public function store(AddFAQRequest $r)
    {
        $data = FAQ::create($r->all());
        $this->done();
        return back();
    }

    public function update($id, Request $r)
    {
        $data = FAQ::where('id',$id)->update($r->except('_token','_method'));
        $this->done();
        return back();
    }

    public function delete($id)
    {
        FAQ::find($id)->delete();
        $this->done();
        return back();
    }
}
