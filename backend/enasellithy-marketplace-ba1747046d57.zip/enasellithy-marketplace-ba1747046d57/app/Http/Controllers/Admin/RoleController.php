<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Role\AddRoleRequest;
use App\Http\Requests\Admin\Role\EditRoleRequest;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class RoleController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = Role::latest()->paginate(10);
        return view('admin.role.index', compact('data'));
    }

    public function create()
    {
        $data = Permission::all();
        return view('admin.role.create', compact('data'));
    }

    public function store(AddRoleRequest $r)
    {
        $role = Role::create(['name' => $r->name,'guard' => 'web']);
        $permissions=$r->permission_id;
        $role->syncPermissions($permissions);
        $this->done();
        return redirect(aurl('roles'));
    }

    public function edit($id)
    {
        $data = Role::find($id);
        $permissions = Permission::all();
        return view('admin.role.edit', compact('data','permissions'));
    }

    public function update($id, EditRoleRequest $r)
    {
        $role = Role::find($id);
        $role->update(['name' => $r->name]);
        $permissions=$r->permission_id;
        $role->syncPermissions($permissions);
        $this->done();
        return redirect(aurl('roles'));
    }
}
