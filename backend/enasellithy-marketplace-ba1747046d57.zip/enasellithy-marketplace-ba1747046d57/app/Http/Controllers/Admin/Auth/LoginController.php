<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class LoginController extends Controller
{
    use MessageTraits;
    public function login_view()
    {
        return view('admin.auth.login');
    }

    public function login_post(Request $r)
    {
        $credentails = $r->validate([
            'email' => [
                'required',
                'email',
                'exists:users,email',
            ],
            'password' => [
                'required',
            ],
        ]);
        if(Auth::attempt($credentails)){
            $r->session()->regenerate();
            return redirect()->intended('/dashboard');
        }else{
            return back()->withErrors([
                'email' => 'the provider credentials do not match',
            ]);
        }
    }

    public function logout()
    {
        Auth::logout();
        return redirect()->intended('/dashboard/login');
    }
}
