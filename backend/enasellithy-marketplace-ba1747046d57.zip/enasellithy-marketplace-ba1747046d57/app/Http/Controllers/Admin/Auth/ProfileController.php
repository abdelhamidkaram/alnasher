<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Auth\UpdateProfileRequest;
use App\Models\User;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    use MessageTraits;
    public function show()
    {
        return view('admin.auth.profile');
    }

    public function updateProfile(UpdateProfileRequest $r)
    {
        User::where('id',auth()->user()->id)->update([
            'name' => $r->name,
            'email' => $r->email,
            'password' => bcrypt($r->password),
        ]);
        $this->done();
        return back();
    }

    public function logout()
    {
        Auth::logout();
        $this->done();
        return redirect(aurl(''));
    }
}
