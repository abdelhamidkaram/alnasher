<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\Admin\AddAdminRequest;
use App\Http\Requests\Admin\Admin\EditAdminRequest;
use App\Http\Requests\Admin\User\AddUserRequest;
use App\Http\Requests\Admin\User\EditUserRequest;
use App\Models\User;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Role;

class UserController extends Controller
{
    use MessageTraits, FileTraits;

    public function index()
    {
        $name = request()->name;
        $data = User::whereHas('roles',function ($q){
            $q->where('name','user');
        })->latest()->paginate(10);
        return view('admin.user.index', compact('data','name'));
    }

    public function user_search()
    {
        $name = request()->name;
        $data = User::whereHas('roles',function ($q){
            $q->where('name','user');
        })->where('name', 'LIKE', '%'.$name.'%')->latest()->paginate(10);
        return view('admin.user.index', compact('data','name'));
    }

    public function store(AddUserRequest $r)
    {
        $role = Role::find($r->role_id);
        $user = User::create($r->all());
        if($r->image){
            $path = "uploads/users/".$user->id."/";
            $name = $user->id.'_'.time();
            $user->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $user->syncRoles($role);
        $this->done();
        return back();
    }

    public function show($id)
    {
        $data = User::with('ads')->find($id);
        return view('admin.user.show', compact('data'));
    }

    public function update($id,EditUserRequest $r)
    {
        $role = Role::find($r->role_id);
        DB::table('model_has_roles')->where('model_id',$id)->delete();
        DB::table('model_has_roles')->insert([
            'model_id' => $id,
            'role_id' => $role->id,
            'model_type' => User::class,
        ]);
        $user = User::where('id',$id)->update($r->except('_token','_method','role_id'));
        if($r->image){
//            if(\File::exists(User::find($id)->image)){
//                unlink(public_path(User::find($id)->image));
//            }
            $path = "uploads/users/".$id."/";
            $name = $id.'_'.time();
            User::where('id',$id)->update([
                'image' => $this->uploadImage($r['image'],$path,$name),
            ]);
        }
        $this->done();
        return back();
    }

    public function delete($id)
    {
//        if(\File::exists(User::find($id)->image)){
//            unlink(public_path(User::find($id)->image));
//        }
        User::find($id)->delete();
        $this->done();
        return back();
    }
}
