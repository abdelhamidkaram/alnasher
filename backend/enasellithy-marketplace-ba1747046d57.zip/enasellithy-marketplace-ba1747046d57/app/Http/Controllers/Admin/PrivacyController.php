<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use function Symfony\Component\String\b;

class PrivacyController extends Controller
{
    use MessageTraits;

    public function index()
    {
        $data = Page::privacy();
        return view('admin.privacy.index', compact('data'));
    }

    public function store(Request $r)
    {
        $data = Page::privacy()->update($r->all());
        $this->done();
        return back();
    }
}
