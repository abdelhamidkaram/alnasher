<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Media;
use App\SOLID\Traits\FileTraits;
use App\SOLID\Traits\MessageTraits;
use Illuminate\Http\Request;
use function Symfony\Component\String\b;

class MediaController extends Controller
{
    use FileTraits, MessageTraits;
    public function delete_image($id)
    {
        $data = Media::find($id);
        if($data->path) {
            if (\File::exists($data->path)) {
                unlink(public_path($data->path));
            }
        }
        $data->delete();
        $this->done();
        return back();
    }
}
