<?php

namespace App\Http\Resources\API;

use Illuminate\Http\Resources\Json\JsonResource;
use function Symfony\Component\String\u;

class UserResource extends JsonResource
{
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id,
            'first_name' => $this->first_name,
            'last_name' => $this->last_name,
            'phone' => $this->phone,
            'email' => $this->email,
            'gender' => $this->gender,
            'dob' => $this->dob,
            'about' => $this->about,
            'image' => \File::exists($this->image) ? url($this->image) : '',
        ];
        return $arr;
    }
}
