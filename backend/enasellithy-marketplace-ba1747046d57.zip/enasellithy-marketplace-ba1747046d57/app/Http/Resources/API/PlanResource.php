<?php

namespace App\Http\Resources\API;

use Illuminate\Http\Resources\Json\JsonResource;

class PlanResource extends JsonResource
{
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id,
            'title' => $this->title,
            'des'  => $this->des,
            'price' => $this->price,
            'count' => $this->count,
        ];
        return $arr;
    }
}
