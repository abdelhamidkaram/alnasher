<?php

namespace App\Http\Resources\API;

use App\Models\Ads;
use App\Models\FavouriatAds;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;

class AdsMediaResource extends JsonResource
{
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id, 
            'image' => !empty($this->path) ? asset($this->path) : '',
        ];
        return $arr;
    }
}
