<?php

namespace App\Http\Resources\API;

use App\Models\Ads;
use App\Models\Category;
use Illuminate\Http\Resources\Json\JsonResource;

class CategoryResource extends JsonResource
{
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id,
            'name' => $this->name,
            'image' => \File::exists($this->image) ? url($this->image) : '',
            'show' => url('api/V1/cats/'.$this->id),
        ];
        $arr['this_main_cat'] = Category::find($this->parent_id) == null ? false : true;
        $arr['main_cat_list'] = new CategoryResource(Category::find($this->parent_id));
        $arr['ads'] = AdsResource::collection(Ads::where('category_id',$this->id)->latest()->paginate(10));
        return $arr;
    }
}
