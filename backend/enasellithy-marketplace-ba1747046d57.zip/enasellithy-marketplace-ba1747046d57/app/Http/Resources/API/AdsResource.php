<?php

namespace App\Http\Resources\API;

use App\Models\Ads;
use App\Models\FavouriatAds;
use App\Models\Media;
use Carbon\Carbon;
use Illuminate\Http\Resources\Json\JsonResource;
use Illuminate\Support\Facades\Auth;

class AdsResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id,
            'title' => $this->title,
            'price' => $this->price,
            'paid_type' => $this->paid_type,
            'phone' => $this->phone,
            'whatsapp' => $this->whatsapp,
            'lat' => $this->lat,
            'active' => $this->active == 'no' ? 'غير مفعل' : 'مفعل',
            'created_at' => Carbon::parse($this->created_at),
            'expire_at' => $this->expire_at,
            'main_image' => new AdsMediaResource(Media::where('model_id',$this->id)->where('model_name',Ads::class)->first()),
            'image_list' => AdsMediaResource::collection(Media::where('model_id',$this->id)->where('model_name',Ads::class)->latest()->get()),
        ];
        $arr['user'] =  new UserResource($this->user);
        $arr['cats'] = $this->cats;
        if(!Auth::guard('api')->check()){
            $arr['fav'] = false;
        }
        else if(Auth::guard('api')->check()){
            if(FavouriatAds::where('user_id',auth_api()->id)
                    ->where('ads_id',$this->id)->count() == 0){
                $arr['fav'] = false;
            }
            if(FavouriatAds::where('user_id',auth_api()->id)
                    ->where('ads_id',$this->id)->count() == 1){
                $arr['fav'] = true;
            }
        }
//        if(Auth::check()){
//            if(FavouriatAds::where('user_id',auth_api()->id)
//                ->where('ads_id',$this->id)->count() == 0){
//                $arr['fav'] = false;
//            }
//            elseif (FavouriatAds::where('user_id',auth_api()->id)
//                    ->where('ads_id',$this->id)->count() == 1){
//                $arr['fav'] = true;
//            }
//        }
//        elseif(!Auth::check()){
//            $arr['fav'] = false;
//        }
        return $arr;
    }
}
