<?php

namespace App\Http\Resources\API;

use Illuminate\Http\Resources\Json\JsonResource;

class SubCategoryResource extends JsonResource
{
    public function toArray($request)
    {
        $arr = [
            'id' => $this->id,
            'name' => $this->name,
            'image' => \File::exists($this->image) ? url($this->image) : '',
        ];
        return $arr;
    }
}
