<?php

namespace App\Console\Commands;

use App\Models\Ads;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Artisan;

class CacheApp extends Command
{
    protected $signature = 'app:cache';

    protected $description = 'Command description';

    public function handle()
    {
        dd(Ads::whereIn('user_id',User::onlyTrashed()->select('id')->get())->get());
        foreach (Ads::whereIn('user_id',User::onlyTrashed()->select('id')->get())->get() as $i){
            Ads::where('id',$i->id)->update(['deleted_at' => Carbon::now()]);
        }
        Artisan::call('config:cache');
        Artisan::call('config:clear');
        Artisan::call('view:cache');
        Artisan::call('view:clear');
        Artisan::call('route:clear');
        return $this->info('Cache !');
    }
}
