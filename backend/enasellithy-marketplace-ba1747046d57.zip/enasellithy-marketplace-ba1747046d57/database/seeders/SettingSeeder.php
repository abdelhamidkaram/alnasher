<?php

namespace Database\Seeders;

use App\Models\Settings;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Settings::create([
            'facebook' => 'facebook',
            'site_name' => 'MarketPlace',
            'email' => 'admin@marketplace.com'
        ]);
    }
}
