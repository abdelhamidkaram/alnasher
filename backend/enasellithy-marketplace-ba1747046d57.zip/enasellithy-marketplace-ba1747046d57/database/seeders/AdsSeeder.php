<?php

namespace Database\Seeders;

use App\Models\Ads;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class AdsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ads::create([
            'title' =>  'Title Title Title',
            'des' =>  'Title Title Title Title Title Title Title Title Title Title Title Title Title Title Title',
            'price' => 100,
            'paid_type' => 'كاش',
            'phone' => '01203298102',
            'category_id' => 1,
            'user_id' => 2,
            'active' => 'yes',
        ]);
    }
}
