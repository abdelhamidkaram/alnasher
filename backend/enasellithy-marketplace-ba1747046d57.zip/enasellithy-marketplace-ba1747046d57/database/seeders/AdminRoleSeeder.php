<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class AdminRoleSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = Role::find(1);
        $role->syncPermissions(Permission::all());
        $admin = User::firstOrCreate([
            'name' => 'admin',
            'email' => 'super@alnsher.com',
            'password' => bcrypt('Hh^3;T?CErIX'),
        ]);
        $admin->syncRoles($role);
    }
}
