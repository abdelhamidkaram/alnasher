<?php

namespace Database\Seeders;

use App\Models\Page;
use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class PrivacyPermissionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::beginTransaction();

        try {
            $data = [
                ['name' => 'privacy.index', 'guard_name' => 'web'],
                ['name' => 'privacy.store', 'guard_name' => 'web'],
                ['name' => 'terms.index', 'guard_name' => 'web'],
                ['name' => 'terms.store', 'guard_name' => 'web'],
                ['name' => 'contact.index', 'guard_name' => 'web'],
                ['name' => 'contact.show', 'guard_name' => 'web'],
            ];
            Permission::insert($data);
            $role = Role::findById(1);
            $role->syncPermissions(Permission::all());
            Page::create([
                'title' => 'Privacy',
                'des' => 'Privacy',
                'slug' => 'privacy',
            ]);
            Page::create([
                'title' => 'Terms',
                'des' => 'Terms',
                'slug' => 'terms',
            ]);
            DB::commit();
            // all good
        } catch (\Exception $e) {
            DB::rollback();
        }
    }
}
