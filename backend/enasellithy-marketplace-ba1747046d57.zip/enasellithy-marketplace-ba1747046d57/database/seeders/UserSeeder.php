<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $role = Role::create(['name' => 'User']);
        $role->syncPermissions(Permission::all());
        $user = User::firstOrCreate([
            'name' => 'user',
            'email' => 'user@mail.com',
            'password' => '123456',
        ]);
        $user->syncRoles($role);

        $user2 = User::firstOrCreate([
            'name' => 'user2',
            'email' => 'user2@mail.com',
            'password' => '123456',
        ]);
        $user2->syncRoles($role);
    }
}
