<?php

namespace Database\Seeders;

use App\Models\Plan;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Spatie\Permission\Models\Permission;

class PlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Plan::create([
            'title' => 'مجانى',
            'price' => 0,
            'count' => 1,
            'status' => 'yes'
        ]);

        Plan::create([
            'title' => 'يومى',
            'price' => 10,
            'count' => 1,
            'status' => 'yes'
        ]);

        Plan::create([
            'title' => 'اسبوعى',
            'price' => 20,
            'count' => 7,
            'status' => 'yes'
        ]);

        Plan::create([
            'title' => 'شهرى',
            'price' => 25,
            'count' => 10,
            'status' => 'yes'
        ]);
    }
}
