<?php

namespace Database\Factories;

use App\Models\Category;
use App\Models\FAQ;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\Category>
 */
class FAQFactory extends Factory
{
    protected $model = FAQ::class;

    public function definition()
    {
        return [
            'title' => $this->faker->name(),
            'des' => $this->faker->paragraph(),
        ];
    }
}
