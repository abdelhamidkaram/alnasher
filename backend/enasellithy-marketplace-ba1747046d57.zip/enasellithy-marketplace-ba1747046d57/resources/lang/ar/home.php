<?php

return [
    'Completed_Campaigns' => 'الحملات المكتمله',
    'Cancelled_Campaigns' => 'الحملات الملغاه',
    'Running_Campaigns' => 'الحملات الحاليه',
];
