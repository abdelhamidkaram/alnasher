<?php

return [
    'check_phone' => 'التحقق من الجوال أو أدخل رقم الجوال',
    'check_pin_code' => 'التحقق من pin code',
    'create_company_profile' => 'إنشاء صفحة الشركة',
    'add_brand' => 'أضف علامة تجارية',
    'add_category' => 'أضف تصنيفات',
    'add_location' => 'أضف موقعك',
    'create_profile' => 'إنشاء ملف شخصي',
    'add_platform' => 'أضف منصة',
    'choose_langauge' => 'إختار اللغة',
    'contact_us' => 'اتصل بنا',
    'new' => 'جديدة',
    'current' => 'حالية',
    'close' => 'مغلقة',
    'create_campaign' => 'إنشاء حملة',
    'campaign_type_ready' => 'حملة جاهزة',
    'campaign_type_live' => 'حملة مباشر',
    'campaign_settings' => 'إعدادات الحملة',
];
