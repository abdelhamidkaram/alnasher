@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row dataTables_wrapper">
            <h4 class="py-3 mb-4"><span class="text-muted fw-light">لوحه التحكم /</span>
                الاعلانات
            </h4>

            <div class="nav-align-top mb-4">
                <div class="tab-content dataTables_wrapper">
                    <div class="card-header flex-column flex-md-row mb-5">
                        <div class="head-label text-center"><h5 class="card-title mb-0">الاعلانات</h5></div>
                        <a href="{{ aurl('ads/create') }}"
                           class="btn btn-primary">
                            انشاء
                        </a>
                        <!-- DataTable with Buttons -->
                    </div>

                    <div class="card">
                        @include('admin.ads.search_bar')
                        <!-- Basic Bootstrap Table -->
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>
                                        الاعلان
                                    </th>
                                    <th>
                                        التصنيف
                                    </th>
                                    <th>
                                        الحاله
                                    </th>
                                    <th>
                                        اداره
                                    </th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                @foreach($data as $i)
                                    <tr>
                                        <td>
                                            <div class="d-flex justify-content-start align-items-center user-name">
                                                <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->id }}
                                                    </span>
                                                    <small class="emp_post text-truncate text-muted">
                                                        {{ $i->title }}
                                                    </small>
                                                    <small class="emp_post text-truncate text-muted">
                                                        ينتهى فى
                                                        <br/>
                                                        {{ Carbon\Carbon::parse($i->expire_at)->format('Y-m-d h:i') }}
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <label class="switch switch-primary">
                                                <a href="{{ aurl('ads/'.$i->id.'/active') }}"
                                                   class="{{ ($i->active == 'no' || $i->active == 'yes') ? 'text-primary' : 'danger' }}"
                                                   title="{{ ($i->active == 'no' || $i->active == 'yes') ? 'اسنعاده' : 'اخفاء' }}">
                                                    @if($i->active == 'no')
                                                        <input type="checkbox" class="switch-input" />
                                                        <span class="switch-toggle-slider">
                                                            <span class="switch-on">
                                                              <i class="ti ti-check"></i>
                                                            </span>
                                                            <span class="switch-off">
                                                              <i class="ti ti-x"></i>
                                                            </span>
                                                          </span>
                                                    @else
                                                        <input type="checkbox" class="switch-input" checked />
                                                        <span class="switch-toggle-slider">
                                                            <span class="switch-on">
                                                              <i class="ti ti-check"></i>
                                                            </span>
                                                            <span class="switch-off">
                                                              <i class="ti ti-x"></i>
                                                            </span>
                                                          </span>
                                                    @endif
                                                </a>
                                            </label>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                @include('admin.ads.btn.action')
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!--/ Basic Bootstrap Table -->
                        <div class="col-sm-12 col-md-12 mt-5 mb-5">
                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                <ul class="pagination justify-content-center">
                                    {{ $data->appends(\Request::all()) }}
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

@endsection



