<div class="flex-column flex-md-row mb-5">
    <form class="card-body" action="{{ aurl('ads_search') }}">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label" for="multicol-username">المنتج</label>
                <input type="text" id="multicol-username" class="form-control" name="title" value="{{ $title }}" />
            </div>
            <div class="col-md-3">
                <label class="form-label" for="multicol-username">المستخدم</label>
                <select class="form-control" name="user_id">
                    <option value=""></option>
                    @foreach(\App\Models\User::whereHas('roles',function ($q){$q->where('name','user');})->latest()->get() as $i)
                        <option value="{{ $i->id }}" {{ $userId == $i->id ? 'selected' : '' }} >
                            {{ $i->fullName() }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label" for="multicol-username">التصينفات</label>
                <select class="form-control" name="category_id">
                    <option value=""></option>
                    @foreach(\App\Models\Category::latest()->get() as $i)
                        <option value="{{ $i->id }}" {{ $category_id == $i->id ? 'selected' : '' }} >
                            {{ $i->name }}
                        </option>
                    @endforeach
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label" for="multicol-username"></label>
                <button type="submit" class="btn btn-secondary" style="margin-top: 25px;">
                    <i class="ti ti-search"></i>
                </button>
            </div>
        </div>
    </form>
</div>
