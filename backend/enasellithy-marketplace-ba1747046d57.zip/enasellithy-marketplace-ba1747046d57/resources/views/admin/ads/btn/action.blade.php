<a class="dropdown-item" href="{{ aurl('ads/'.$i->id.'/edit') }}">
    <i class="ti ti-pencil me-1"></i>
    تعديل
</a>
<div
    class="offcanvas offcanvas-end"
    tabindex="-1"
    id="offcanvasEnd_{{$i->id}}"
    aria-labelledby="offcanvasEndLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="exampleModalLabel">
            تعديل
        </h5>
        <button
            type="button"
            class="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="add-new-record pt-0 row g-2" enctype="multipart/form-data" action="{{ aurl('ads/'.$i->id) }}" method="post">
            <input type="hidden" name="_token" value="{{csrf_token()}}">
            <input type="hidden" name="_method" value="put">
            @csrf
{{--            <div class="col-sm-12">--}}
{{--                <label class="form-label" for="basicPost">--}}
{{--                    تصنيف رئيسى--}}
{{--                </label>--}}
{{--                <div class="input-group input-group-merge">--}}
{{--                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>--}}
{{--                    <select name="parent_id" class="form-select">--}}
{{--                        <option selected disabled>...</option>--}}
{{--                        @foreach(\App\Models\Category::get() as $v)--}}
{{--                            <option value="{{ $v->id }}" {{ $i->parent_id == $v->id ? 'selected' : '' }}>--}}
{{--                                {{ $v->name }}--}}
{{--                            </option>--}}
{{--                        @endforeach--}}
{{--                    </select>--}}
{{--                </div>--}}
{{--            </div>--}}
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الاسم
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="text"
                        id="basicPost"
                        name="name" value="{{ $i->name }}"
                        class="form-control @error('name') is-invalid @enderror" placeholder="name" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الصوره
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="file"
                        id="basicPost"
                        name="image" value="{{ $i->image }}"
                        class="form-control @error('image') is-invalid @enderror" placeholder="image" />
                </div>
                <br/>
                @if(\File::exists($i->image))
                    <img src="{{ asset($i->image) }}" class="img-thumbnail" width="100">
                @endif
            </div>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary data-submit me-sm-3 me-1">حفظ</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">الغاء</button>
            </div>
        </form>
    </div>
</div>

<a class="dropdown-item" href="{{ aurl('ads/'.$i->id) }}">
    <i class="ti ti-eye me-1"></i>
    عرض
</a>

<a class="dropdown-item" href="{{ aurl('ads/delete/'.$i->id) }}">
    <i class="ti ti-trash me-1"></i>
    حذف
</a>

