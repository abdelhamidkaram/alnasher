@extends('admin.layouts.app')

@push('css')
    <link type="text/css" rel="stylesheet" href="{{ asset('assets/css/image-uploader.min.css') }}">
@endpush

@section('content')

    <div class="content-wrapper container-xxl p-0">
        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">لوحه التحكم /</span>
            الاعلانات
        </h4>
        <div class="content-header row">
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h4 class="card-title">
                                جديد
                            </h4>
                        </div>
                        <div class="card-body py-2 my-25">

                            <!-- form -->
                            <form class="validate-form mt-2 pt-50" action="{{ aurl('ads') }}" method="post" enctype="multipart/form-data">
                                @csrf
                                <div class="row">
                                    <div class="col-12 col-sm-12 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            اسم المنتج
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <input type="text" class="form-control" id="accountFirstName" name="title"
                                                   value="{{ old('title') }}" data-msg="Please enter title" />
                                            <br/>
                                            @if ($errors->has('title'))
                                                <span class="text-danger">{{ $errors->first('title') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-3 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            التصنيف
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <select id="category_id" class="form-control" name="category_id" style="width: 100% !important;">
                                                <option selected disabled>...</option>
                                                @foreach($data as $i)
                                                    <option value="{{ $i->id }}" {{ old('category_id') ? 'selected' : '' }} >
                                                        {{ $i->name }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <br/>
                                            @if ($errors->has('category_id'))
                                                <span class="text-danger">{{ $errors->first('category_id') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-4 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            السعر
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <input type="number" class="form-control" id="accountFirstName" name="price"
                                                   value="{{ old('price') }}" data-msg="Please enter price" />
                                            <br/>
                                            @if ($errors->has('price'))
                                                <span class="text-danger">{{ $errors->first('price') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-4 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            الجوال
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <input type="number" class="form-control" id="phone" name="phone"
                                                   value="{{ old('phone') }}" data-msg="Please enter phone" />
                                            <br/>
                                            @if ($errors->has('phone'))
                                                <span class="text-danger">{{ $errors->first('phone') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-4 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                             الواتساب
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <input type="text" class="form-control" id="whatsapp" name="whatsapp"
                                                   value="{{ old('whatsapp') }}" data-msg="Please enter whatsapp" />
                                            <br/>
                                            @if ($errors->has('whatsapp'))
                                                <span class="text-danger">{{ $errors->first('whatsapp') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-4 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            اسم المعلن
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <select class="form-control" name="user_id" required>
                                                <option selected disabled>...</option>
                                                @foreach(\App\Models\User::whereHas('roles',function ($q){$q->where('name','user');})->get() as $i)
                                                    <option value="{{ $i->id }}">
                                                        {{ $i->fullName() }}
                                                    </option>
                                                @endforeach
                                            </select>
                                            <br/>
                                            @if ($errors->has('user_id'))
                                                <span class="text-danger">{{ $errors->first('user_id') }}</span>
                                            @endif
                                        </div>
                                    </div>

{{--                                    <div class="col-12 col-sm-3 mb-1">--}}
{{--                                        <label class="form-label" for="accountFirstName">--}}
{{--                                            المعلن (مالك / وسيط)--}}
{{--                                        </label>--}}
{{--                                        <div class="input-group input-group-merge">--}}
{{--                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>--}}
{{--                                            <input type="text" class="form-control" id="adv_by" name="adv_by"--}}
{{--                                                   value="{{ old('adv_by') }}" data-msg="Please enter adv_by" />--}}
{{--                                            @if ($errors->has('adv_by'))--}}
{{--                                                <span class="text-danger">{{ $errors->first('adv_by') }}</span>--}}
{{--                                            @endif--}}
{{--                                        </div>--}}
{{--                                    </div>--}}

                                    <div class="col-12 col-sm-12 mb-1">
                                        <label class="form-label" for="accountFirstName">
                                            الوصف
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                            <input type="text" class="form-control" id="accountFirstName" name="des"
                                                   value="{{ old('des') }}" data-msg="Please enter des" />
                                            <br/>
                                            @if ($errors->has('des'))
                                                <span class="text-danger">{{ $errors->first('des') }}</span>
                                            @endif
                                        </div>
                                    </div>

                                    <div class="col-12 col-sm-12 mb-1">
{{--                                        <div class="input-group input-group-merge">--}}
{{--                                            <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>--}}
{{--                                            <input--}}
{{--                                                type="file" onchange="checkFiles(this.files)"--}}
{{--                                                name="image[]" value="{{ old('image') }}" accept="image/png, image/jpg, image/jpeg" min="1" max="5"--}}
{{--                                                class="form-control @error('image') is-invalid @enderror" placeholder="image" multiple />--}}
{{--                                        </div>--}}
                                        <div id="image-preview">
                                            <label for="image-upload" id="image-label">الصور</label>
{{--                                            <input type="file" name="image" id="image-upload" />--}}
                                            <div class="input-images-1" style="padding-top: .5rem;"></div>
                                        </div>
                                    </div>

                                    <div class="col-12">
                                        <div id="buttons" style="float:left;">
                                            <button type="submit" class="btn btn-primary mt-1 me-1">حفظ</button>
                                            <a href="{{ aurl('ads') }}" class="btn btn-outline-secondary mt-1">عوده</a>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <!--/ form -->
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

    @push('js')
        <script src="{{ asset('assets/js/image-uploader.min.js') }}"></script>
        <script type="text/javascript">
            $(document).ready(function() {
                $('.input-images-1').imageUploader();
            });
        </script>
    @endpush

@endsection


