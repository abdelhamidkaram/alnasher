@extends('admin.layouts.app')

@section('content')

    <div class="content-wrapper container-xxl p-0">
        <h4 class="py-3 mb-4">
            <span class="text-muted fw-light">لوحه التحكم /</span>
            الاعلانات
        </h4>
        <div class="content-header row">
        </div>
        <div class="content-body">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header border-bottom">
                            <h4 class="card-title">
                                عرض
                            </h4>
                        </div>
                        <div class="card-body py-2 my-25">
                            <div class="row">
                                <div class="col-12 col-sm-12 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        اسم المنتج
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <input type="text" class="form-control" id="accountFirstName" name="title"
                                               value="{{ $data->title }}" disabled />
                                    </div>
                                </div>

                                <div class="col-12 col-sm-3 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        التصنيف
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <select id="category_id" class="form-control" name="category_id" style="width: 100% !important;" disabled>
                                            <option selected disabled>...</option>
                                            @foreach(\App\Models\Category::get() as $i)
                                                <option value="{{ $i->id }}" {{ $data->category_id ? 'selected' : '' }} >
                                                    {{ $i->name }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>

                                <div class="col-12 col-sm-4 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        السعر
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <input type="number" class="form-control" id="accountFirstName" name="price"
                                               value="{{ $data->price }}" data-msg="Please enter price" disabled />
                                    </div>
                                </div>

                                <div class="col-12 col-sm-4 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        الجوال
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <input type="number" class="form-control" id="phone" name="phone"
                                               value="{{ $data->phone }}" data-msg="Please enter phone" disabled />
                                    </div>
                                </div>

                                <div class="col-12 col-sm-4 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        الواتساب
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <input type="text" class="form-control" id="whatsapp" name="whatsapp"
                                               value="{{ $data->whatsapp }}" data-msg="Please enter whatsapp" disabled />
                                    </div>
                                </div>

                                <div class="col-12 col-sm-4 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        اسم المعلن
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <select class="form-control" name="user_id" disabled>
                                            <option selected disabled>...</option>
                                            @foreach(\App\Models\User::whereHas('roles',function ($q){$q->where('name','user');})->get() as $i)
                                                <option value="{{ $i->id }}" {{ $data->user_id == $i->id ? 'selected' : '' }} >
                                                    {{ $i->fullName() }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 col-sm-12 mb-1">
                                    <label class="form-label" for="accountFirstName">
                                        الوصف
                                    </label>
                                    <div class="input-group input-group-merge">
                                        <span id="basicFullname2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                        <input type="text" class="form-control" id="accountFirstName" name="des"
                                               value="{{ $data->des }}" data-msg="Please enter des" />
                                    </div>
                                </div>

                                <div class="col-12 col-sm-12 mb-1">
                                    <div id="image-preview">
                                       @foreach($data->media as $i)
                                           <img src="{{ asset($i->path) }}" height="250" width="250"
                                                class="img-thumbnail">
                                        @endforeach
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>

    </div>

@endsection


