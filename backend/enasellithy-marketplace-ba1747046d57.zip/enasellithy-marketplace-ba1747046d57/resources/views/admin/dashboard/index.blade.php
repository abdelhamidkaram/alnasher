@extends('admin.layouts.app')

@push('css')
@endpush

@section('content')


    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
        </div>
    </div>
    <div class="content-body">
        <div class="row mb-4 g-4">
            <div class="col-sm-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="content-left">
                                <h4 class="mb-0">
                                    {{ \App\Models\Ads::count() }}
                                </h4>
                                <small>اعلانات</small>
                            </div>
                            <span class="badge bg-label-primary rounded-circle p-2">
                                <i class="ti ti-tags ti-md"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="content-left">
                                <h4 class="mb-0">
                                    {{ \App\Models\User::whereHas('roles',function ($q){$q->where('name','user');})->count() }}
                                </h4>
                                <small>المستخدمين</small>
                            </div>
                            <span class="badge bg-label-danger rounded-circle p-2">
                                <i class="ti ti-user ti-md"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="content-left">
                                <h4 class="mb-0">{{ \App\Models\Category::count() }}</h4>
                                <small>
                                    التصنيفات
                                </small>
                            </div>
                            <span class="badge bg-label-info rounded-circle p-2">
                                <i class="ti ti-infinity ti-md"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-6 col-xl-3">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-center justify-content-between">
                            <div class="content-left">
                                <h4 class="mb-0">{{ \App\Models\UserPlan::sum('amount') }}</h4>
                                <small>
                                    اجمالى الربح بالدينار
                                </small>
                            </div>
                            <span class="badge bg-label-info rounded-circle p-2">
                                <i class="ti ti-infinity ti-md"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="row mb-4 g-4">
            <div class="card">
                <div class="card-header">
                    المستخدمين
                </div>
                <!-- Basic Bootstrap Table -->
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>
                                الاسم
                            </th>
                            <th>
                                تاريخ التسجيل
                            </th>
                            <th>
                                اداره
                            </th>
                        </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        @foreach(\App\Models\User::whereHas('roles',function ($q){$q->where('name','user');})->latest()->paginate(10) as $i)
                            <tr>
                                <td>
                                    <div class="d-flex justify-content-start align-items-center user-name">
                                        <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                      {{ $i->email }}
                                                    </span>
                                            <small class="emp_post text-truncate text-muted">
                                                {{ $i->fullName()  }}
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    {{ \Carbon\Carbon::parse($i->created_at)->format('d-m-Y') }}
                                </td>
                                <td>
                                    <div class="d-flex">
                                        @include('admin.user.btn.action')
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="row mb-4 g-4">
            <div class="card">
                <div class="card-header">
                    اﻻعلانات
                </div>
                <!-- Basic Bootstrap Table -->
                <div class="table-responsive text-nowrap">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>
                                الاعلان
                            </th>

                            
                            <th>
                                التصنيف
                            </th>
                            <th>
                                اداره
                            </th>
                        </tr>
                        </thead>
                        <tbody class="table-border-bottom-0">
                        @foreach($data as $i)
                            <tr>
                                <td>
                                    <div class="d-flex justify-content-start align-items-center user-name">
                                        <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->id }}
                                                    </span>
                                            <small class="emp_post text-truncate text-muted">
                                                {{ $i->title }}
                                            </small>
                                            <small class="emp_post text-truncate text-muted">
                                                {{ $i->create_at }}
                                            </small>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex justify-content-start align-items-center user-name">
                                        <div class="avatar-wrapper">
                                            <div class="avatar me-2">
                                                @if(\File::exists($i->cats->image))
                                                    <img src="{{ asset($i->cats->image) }}" alt="Avatar" class="rounded-circle">
                                                @endif
                                            </div>
                                        </div>
                                        <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->cats->name }}
                                                    </span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        @include('admin.ads.btn.action')
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    @push('js')

    @endpush

@endsection
