@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row dataTables_wrapper">
            <h4 class="py-3 mb-4"><span class="text-muted fw-light">لوحه التحكم /</span>
                الادوار
            </h4>

            <div class="nav-align-top mb-4">
                <div class="tab-content dataTables_wrapper">
                    <div class="card-header flex-column flex-md-row mb-5">
                        <div class="head-label text-center"><h5 class="card-title mb-0">الادوار</h5></div>
                        <a href="{{ aurl('roles/create') }}" class="btn btn-primary">
                            انشاء
                        </a>
                        <!-- DataTable with Buttons -->
                    </div>

                    <div class="card">
                        <!-- Basic Bootstrap Table -->
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>
                                        الاسم
                                    </th>
                                    <th>
                                        اداره
                                    </th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                @foreach($data as $i)
                                    <tr>
                                        <td>
                                            {{ $i->name }}
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                @include('admin.role.btn.action')
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!--/ Basic Bootstrap Table -->
                        <div class="col-sm-12 col-md-12 mt-5 mb-5">
                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                <ul class="pagination justify-content-center">
                                    {{ $data->links() }}
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

@endsection



