<a class="text-gray" href="{{ aurl('roles/'.$i->id.'/edit') }}">
<i class="ti ti-pencil me-1"></i>
    تعديل
</a>

<!-- Button trigger modal -->
{{--<button type="button" class="btn bg-gradient-primary" data-bs-toggle="modal" data-bs-target="#delete_{{$id}}">--}}
{{--    <i class="fa fa-trash"></i>--}}
{{--</button>--}}

<!-- Modal -->
{{--<div class="modal fade" id="delete_{{$id}}" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">--}}
{{--    <div class="modal-dialog">--}}
{{--        <div class="modal-content">--}}
{{--            <div class="modal-header">--}}
{{--                <h5 class="modal-title" id="exampleModalLabel">--}}
{{--                    {{ trans('admin.delete') }}--}}
{{--                </h5>--}}
{{--                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>--}}
{{--            </div>--}}
{{--            {!! Form::open(['route'=>['screens.destroy',$id],'method'=>'delete']) !!}--}}
{{--            <div class="modal-body">--}}
{{--                {{ trans('admin.delete_this') }}--}}
{{--            </div>--}}
{{--            <div class="modal-footer">--}}
{{--                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>--}}
{{--                {!! Form::submit(trans('admin.yes'),['class'=>'btn btn-danger']) !!}--}}
{{--            </div>--}}
{{--            {!! Form::close() !!}--}}
{{--        </div>--}}
{{--    </div>--}}
{{--</div>--}}
