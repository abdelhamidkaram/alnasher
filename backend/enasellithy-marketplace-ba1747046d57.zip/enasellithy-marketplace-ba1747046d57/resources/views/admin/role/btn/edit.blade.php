<a href="{{ aurl('screens/'.$id.'/edit') }}" class="btn btn-info"><i class="fa fa-edit"></i></a>
