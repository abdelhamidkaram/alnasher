<input type="checkbox" name="item[]" class="item_checkbox" value="{{ $id }}">
