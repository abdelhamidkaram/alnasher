@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')


    <div class="row">
        <div class="col-12">
            <div class="container">
                <div class="card my-4">



                    <div class="card-header p-0 position-relative mt-n4 mx-3 z-index-2">
                        <div class="bg-gradient-primary shadow-primary border-radius-lg pt-4 pb-3">
                            <h6 class="text-white text-capitalize ps-3">
                                {{ trans('admin.roles') }}
                            </h6>
                        </div>
                    </div>
                    <div class="card-body px-0 pb-2" style="margin-right: 15px;margin-left: 15px;">
                        <div class="table-responsive p-0">
                            @can('role.create')
                            <a class="btn btn-primary" href="{{ aurl('role/create') }}" >
                                {{ trans('admin.create') }}
                            </a>
                            @endcan
                            {!! Form::open(['id'=>'form_data','url'=>aurl('screens/destroy/all'),'method'=>'delete']) !!}
                            {!! $dataTable->table(['class'=>'table align-items-center mb-0','id' => 'role'],true) !!}
                            {!! Form::close() !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    @push('js')
        {!! $dataTable->scripts() !!}
        <script>
            if ( $.fn.dataTable.isDataTable( '#role' ) ) {
              table = $('#screen').DataTable({
                  "processing": true,
                  "serverSide": true,
                });
            }
            // $(document).ready( function () {
            //     $("#screen").dataTable({
            //
            //         // dom: 'Bfrtip',
            //         // buttons: [
            //         //     'copyHtml5',
            //         //     'excelHtml5',
            //         //     'csvHtml5',
            //         //     'pdfHtml5'
            //         // ]
            //     });
            // } );
        </script>
    @endpush

@endsection


