@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row dataTables_wrapper">
            <h4 class="py-3 mb-4"><span class="text-muted fw-light">لوحه التحكم /</span> المستخدمين</h4>

            <div class="nav-align-top mb-4">
                <div class="tab-content dataTables_wrapper">
                    <div class="card-header flex-column flex-md-row mb-5">
                        <div class="head-label text-center"><h5 class="card-title mb-0">المستخدمين</h5></div>
                        <!-- DataTable with Buttons -->
                    </div>

                    <div class="card">
                        <div class="card-header">
                            {{ $data->fullName() }}
                        </div>
                        <div class="card-body">
                            <div>
                                <h3>معلومات شخصيه</h3>
                                <hr/>
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label class="form-label" for="basicPost">
                                            الاسم
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <input class="form-control" value="{{ $data->fullName() }}" disabled/>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <label class="form-label" for="basicPost">
                                            الايميل
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <input class="form-control" value="{{ $data->email }}" disabled/>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <label class="form-label" for="basicPost">
                                            الجوال
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <input class="form-control" value="{{ $data->phone }}" disabled/>
                                        </div>
                                    </div>
                                    <div class="col-sm-3">
                                        <label class="form-label" for="basicPost">
                                            تاريخ التسجيل
                                        </label>
                                        <div class="input-group input-group-merge">
                                            <input class="form-control" value="{{ \Carbon\Carbon::parse($data->created_at)->format('Y-m-d h:i') }}" disabled/>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <br/>
                            <div>
                                <h3>الاعلانات</h3>
                                <hr/>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <div class="table-responsive text-nowrap">
                                            <table class="table">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        الاعلان
                                                    </th>
                                                    <th>
                                                        المستخدم
                                                    </th>
                                                    <th>
                                                        التصنيف
                                                    </th>
                                                    <th>
                                                        اداره
                                                    </th>
                                                </tr>
                                                </thead>
                                                <tbody class="table-border-bottom-0">
                                                @foreach($data->ads as $i)
                                                    <tr>
                                                        <td>
                                                            <div class="d-flex justify-content-start align-items-center user-name">
                                                                <div class="avatar-wrapper">
                                                                    <div class="avatar me-2">
                                                                        @if(\File::exists($i->user->image))
                                                                            <img src="{{ asset($i->user->image) }}" alt="Avatar" class="rounded-circle">
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->id }}
                                                    </span>
                                                                    <small class="emp_post text-truncate text-muted">
                                                                        {{ $i->title }}
                                                                    </small>
                                                                    <small class="emp_post text-truncate text-muted">
                                                                        {{ $i->create_at }}
                                                                    </small>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex justify-content-start align-items-center user-name">
                                                                <div class="avatar-wrapper">
                                                                    <div class="avatar me-2">
                                                                        @if(\File::exists($i->user->image))
                                                                            <img src="{{ asset($i->user->image) }}" alt="Avatar" class="rounded-circle">
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->user->phone }}
                                                    </span>
                                                                    <small class="emp_post text-truncate text-muted">
                                                                        {{ $i->user->name }}
                                                                    </small>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex justify-content-start align-items-center user-name">
                                                                <div class="avatar-wrapper">
                                                                    <div class="avatar me-2">
                                                                        @if(\File::exists($i->cats->image))
                                                                            <img src="{{ asset($i->cats->image) }}" alt="Avatar" class="rounded-circle">
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                                <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                        {{ $i->cats->name }}
                                                    </span>
                                                                </div>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="d-flex">
                                                                @include('admin.ads.btn.action')
                                                            </div>
                                                        </td>
                                                    </tr>
                                                @endforeach
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

@endsection
