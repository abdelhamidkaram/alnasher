<div class="flex-column flex-md-row mb-5">
    <form class="card-body" action="{{ aurl('user_search') }}">
        <div class="row g-3">
            <div class="col-md-3">
                <label class="form-label" for="multicol-username">الاسم</label>
                <input type="text" id="multicol-username" class="form-control" name="name" value="{{ $name }}" />
            </div>
            <div class="col-md-3">
                <label class="form-label" for="multicol-username"></label>
                <button type="submit" class="btn btn-secondary" style="margin-top: 25px;">
                    <i class="ti ti-search"></i>
                </button>
            </div>
        </div>
    </form>
</div>
