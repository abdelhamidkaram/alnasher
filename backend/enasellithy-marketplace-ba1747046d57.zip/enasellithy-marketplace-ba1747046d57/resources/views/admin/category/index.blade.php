@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row dataTables_wrapper">
            <h4 class="py-3 mb-4"><span class="text-muted fw-light">لوحه التحكم /</span>
                التصنيفات
            </h4>

            <div class="nav-align-top mb-4">
                <div class="tab-content dataTables_wrapper">
                    <div class="card-header flex-column flex-md-row mb-5">
                        <div class="head-label text-center"><h5 class="card-title mb-0">التصنيفات</h5></div>
                        @include('admin.category.create')
                        <!-- DataTable with Buttons -->
                    </div>

                    <div class="card">
                        <!-- Basic Bootstrap Table -->
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>
                                        الصوره
                                    </th>
                                    <th>
                                        الاسم
                                    </th>
                                    <th>
                                        تصنيف فرعى
                                    </th>
                                    <th>
                                        اداره
                                    </th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                @foreach($data as $i)
                                    <tr>
                                        <td>
                                            @if(\File::exists($i->image))
                                                <img src="{{ asset($i->image) }}" class="img-thumbnail" width="100">
                                            @endif
                                        </td>
                                        <td>
                                           {{ $i->name }}
                                        </td>
                                        <td>
                                            <table class="table">
                                                @foreach(\App\Models\Category::where('parent_id',$i->id)->get() as $v)
                                                    <tr>
                                                        <th>
                                                            {{ $v->name }}
                                                        </th>
                                                        <th>
                                                            @include('admin.category.btn.actions')
                                                        </th>
                                                    </tr>
                                                @endforeach
                                            </table>
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                @include('admin.category.btn.action')
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!--/ Basic Bootstrap Table -->
                        <div class="col-sm-12 col-md-12 mt-5 mb-5">
                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                <ul class="pagination justify-content-center">
                                    {{ $data->links() }}
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

@endsection



