@extends('admin.layouts.app')

@section('content')


    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">


            <!-- Basic Vertical form layout section start -->
            <section id="basic-vertical-layouts">
                <div class="row">
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    {{ trans('admin.fqa') }}
                                </h4>
                            </div>
                            <div class="card-body">
                                <form class="form form-vertical" action="{{ aurl('fqa/'.$data->id) }}" method="post">
                                    <input type="hidden" name="_token" value="{{csrf_token()}}">
                                    <input type="hidden" name="_method" value="put">
                                    <div class="row">


                                        @foreach($getTrans as $l)
                                            <div class="col-12">
                                                <div class="mb-1">
                                                    <label class="form-label">{{$l->key}}_{{$l->lang_key}}</label>
                                                    <input type="text" name="{{$l->key}}[{{$l->id}}]" value="{{ $l->value }}"
                                                           class="form-control"
                                                           required>
                                                </div>
                                            </div>
                                        @endforeach

                                        <div class="col-12">
                                            <div class="mb-1">
                                                <div class="demo-inline-spacing">
                                                    <div class="form-check form-check-primary">
                                                        <input type="radio" class="form-check-input" id="colorCheck1" name="status" value="influancer" {{ $data->status == 'influancer' ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="colorCheck1">
                                                            {{ trans('admin.Influancer_App') }}
                                                        </label>
                                                    </div>
                                                    <div class="form-check form-check-primary">
                                                        <input type="radio" class="form-check-input" id="colorCheck1" name="status" value="influancer" {{ $data->status == 'advertiser' ? 'checked' : '' }} >
                                                        <label class="form-check-label" for="colorCheck1">
                                                            {{ trans('admin.Advertiser_App') }}
                                                        </label>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>



                                        <div class="col-12">
                                            <button type="submit" class="btn btn-primary me-1">
                                                {{ trans('admin.save') }}
                                            </button>
                                            <a href="{{ aurl('fqa') }}" class="btn btn-outline-secondary">
                                                {{ trans('admin.back') }}
                                            </a>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Basic Vertical form layout section end -->


        </div>
    </div>

@endsection


