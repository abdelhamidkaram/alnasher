<button
    class="btn btn-primary"
    type="button"
    data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasEnd"
    aria-controls="offcanvasEnd">
    انشاء
</button>
<div
    class="offcanvas offcanvas-end"
    tabindex="-1"
    id="offcanvasEnd"
    aria-labelledby="offcanvasEndLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="exampleModalLabel">جديد</h5>
        <button
            type="button"
            class="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="add-new-record pt-0 row g-2"
              action="{{ aurl('plan') }}" method="post" enctype="multipart/form-data">
            @csrf
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الاسم
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <select class="form-control" name="title">
                        <option selected disabled>...</option>
                        @foreach(plan() as $i)
                            <option value="{{ $i }}" {{ old('title') == $i ? 'selected' : '' }} >
                                {{ $i }}
                            </option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    السعر
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="number"
                        id="basicPost"
                        name="price" value="{{ old('price') }}"
                        class="form-control @error('price') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    عدد ايام المشاهدات
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="number"
                        id="basicPost"
                        name="count" value="{{ old('count') }}"
                        class="form-control @error('count') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary data-submit me-sm-3 me-1">حفظ</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">الغاء</button>
            </div>
        </form>
    </div>
</div>
