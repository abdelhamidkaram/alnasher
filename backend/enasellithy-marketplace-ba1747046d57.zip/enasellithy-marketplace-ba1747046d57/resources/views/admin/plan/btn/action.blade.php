<a
    type="button"
    data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasEnd_{{$i->id}}"
    aria-controls="offcanvasEnd">
    <i class="ti ti-pencil me-1"></i>
    تعديل
</a>
<div
    class="offcanvas offcanvas-end"
    tabindex="-1"
    id="offcanvasEnd_{{$i->id}}"
    aria-labelledby="offcanvasEndLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="exampleModalLabel">
            تعديل
        </h5>
        <button
            type="button"
            class="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="add-new-record pt-0 row g-2" enctype="multipart/form-data" action="{{ aurl('category/'.$i->id) }}" method="post">
            <input type="hidden" name="_token" value="{{csrf_token()}}">
            <input type="hidden" name="_method" value="put">
            @csrf
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    النوع
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input disabled
                        type="text" id="basicPost" value="{{ $i->title }}"
                        class="form-control @error('name') is-invalid @enderror" placeholder="name" />
                </div>
            </div>

            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    السعر
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                           type="number"
                           id="basicPost"
                           name="price" value="{{ $i->price }}"
                           class="form-control @error('price') is-invalid @enderror" />
                </div>
            </div >

            <div  class="col-sm-12" >
                <label class="form-label" for="basicPost">
                    عدد الاعلانات
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input type="number"
                           id="basicPost" name="count" value="{{ $i->count }}" class="form-control @error('count') is-invalid @enderror" />
                </div>
            </div>

            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary data-submit me-sm-3 me-1">حفظ</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">الغاء</button>
            </div>
        </form>
    </div>
</div>
{{--<a class="dropdown-item" href="{{ aurl('category/delete/'.$i->id) }}">--}}
{{--    <i class="ti ti-trash me-1"></i>--}}
{{--    حذف--}}
{{--</a>--}}
