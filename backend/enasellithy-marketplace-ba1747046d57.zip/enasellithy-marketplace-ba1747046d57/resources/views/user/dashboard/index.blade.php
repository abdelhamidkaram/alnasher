@extends('admin.layouts.app')

@section('content')


    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
        </div>
    </div>
    <div class="content-body">
        <!-- Statistics card section -->
        <section id="statistics-card">
            <!-- Miscellaneous Charts -->

        </section>
        <!--/ Statistics Card section-->

    </div>

    @push('js')

    @endpush

@endsection
