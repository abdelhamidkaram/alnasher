@extends('admin.layouts.app')

@push('css')

@endpush

@section('content')

    <!-- Content -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <div class="row dataTables_wrapper">
            <h4 class="py-3 mb-4"><span class="text-muted fw-light">لوحه التحكم /</span> الاداره</h4>

            <div class="nav-align-top mb-4">
                <div class="tab-content dataTables_wrapper">
                    <div class="card-header flex-column flex-md-row mb-5">
                        <div class="head-label text-center"><h5 class="card-title mb-0">اﻻداره</h5></div>
                        @include('admin.admin.create')
                        <!-- DataTable with Buttons -->
                    </div>

                    <div class="card">
                        <!-- Basic Bootstrap Table -->
                        <div class="table-responsive text-nowrap">
                            <table class="table">
                                <thead>
                                <tr>
                                    <th>
                                        الاسم
                                    </th>
                                    <th>
                                        تاريخ التسجيل
                                    </th>
                                    <th>
                                        اداره
                                    </th>
                                </tr>
                                </thead>
                                <tbody class="table-border-bottom-0">
                                @foreach($data as $i)
                                    <tr>
                                        <td>
                                            <div class="d-flex justify-content-start align-items-center user-name">
                                                <div class="avatar-wrapper">
                                                    <div class="avatar me-2">
                                                        @if(\File::exists($i->image))
                                                            <img src="{{ asset($i->image) }}" alt="{{ $i->name }}" class="rounded-circle">
                                                        @endif
                                                    </div>
                                                </div>
                                                <div class="d-flex flex-column">
                                                    <span class="emp_name text-truncate">
                                                      {{ $i->phone }}
                                                    </span>
                                                    <small class="emp_post text-truncate text-muted">
                                                        {{ $i->name }}
                                                    </small>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            {{ \Carbon\Carbon::parse($i->created_at)->format('d-m-Y') }}
                                        </td>
                                        <td>
                                            <div class="d-flex">
                                                @include('admin.admin.btn.action')
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                                </tbody>
                            </table>
                        </div>
                        <!--/ Basic Bootstrap Table -->
                        <div class="col-sm-12 col-md-12 mt-5 mb-5">
                            <div class="dataTables_paginate paging_simple_numbers" id="DataTables_Table_0_paginate">
                                <ul class="pagination justify-content-center">
                                    {{ $data->links() }}
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
    <!-- / Content -->

@endsection
