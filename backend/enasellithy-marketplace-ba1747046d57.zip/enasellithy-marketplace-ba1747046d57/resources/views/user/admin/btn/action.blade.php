<a
    type="button"
    data-bs-toggle="offcanvas"
    data-bs-target="#offcanvasEnd_{{$i->id}}"
    aria-controls="offcanvasEnd">
    <i class="ti ti-pencil me-1"></i>
    تعديل
</a>
<div
    class="offcanvas offcanvas-end"
    tabindex="-1"
    id="offcanvasEnd_{{$i->id}}"
    aria-labelledby="offcanvasEndLabel">
    <div class="offcanvas-header border-bottom">
        <h5 class="offcanvas-title" id="exampleModalLabel">
            تعديل
        </h5>
        <button
            type="button"
            class="btn-close text-reset"
            data-bs-dismiss="offcanvas"
            aria-label="Close"></button>
    </div>
    <div class="offcanvas-body flex-grow-1">
        <form class="add-new-record pt-0 row g-2" enctype="multipart/form-data" action="{{ aurl('admin/'.$i->id) }}" method="post">
            <input type="hidden" name="_token" value="{{csrf_token()}}">
            <input type="hidden" name="_method" value="put">
            @csrf
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الاسم
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="text"
                        id="basicPost"
                        name="name" value="{{ $i->name }}"
                        class="form-control @error('name') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    اﻻيميل
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-mail"></i></span>
                    <input
                        type="email"
                        id="basicPost"
                        name="email" value="{{ $i->email }}"
                        class="form-control @error('email') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الجوال
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-phone"></i></span>
                    <input
                        type="text"
                        id="basicPost"
                        name="phone" value="{{ $i->phone }}"
                        class="form-control @error('phone') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    كلمه المرور
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-key"></i></span>
                    <input
                        type="password"
                        id="basicPost"
                        name="password" value="{{ old('password') }}"
                        class="form-control @error('password') is-invalid @enderror" />
                </div>
            </div>
            <div class="col-sm-12">
                <label class="form-label" for="basicPost">
                    الصوره
                </label>
                <div class="input-group input-group-merge">
                    <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                    <input
                        type="file"
                        id="basicPost"
                        name="image" value="{{ $i->image }}"
                        class="form-control @error('image') is-invalid @enderror" placeholder="image" />
                </div>
                <br/>
                @if(\File::exists($i->image))
                    <img src="{{ asset($i->image) }}" class="img-thumbnail" width="100">
                @endif
            </div>
            <input type="hidden" name="role_id" value="1">
            <div class="col-sm-12">
                <button type="submit" class="btn btn-primary data-submit me-sm-3 me-1">حفظ</button>
                <button type="reset" class="btn btn-outline-secondary" data-bs-dismiss="offcanvas">الغاء</button>
            </div>
        </form>
    </div>
</div>
@if(auth()->id() != $i->id)
<a class="dropdown-item" href="{{ aurl('category/delete/'.$i->id) }}">
    <i class="ti ti-trash me-1"></i>
    حذف
</a>
@endif
