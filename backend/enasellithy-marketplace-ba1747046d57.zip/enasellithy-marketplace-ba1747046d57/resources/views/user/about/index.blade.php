@extends('admin.layouts.app')

@section('content')


    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">


            <!-- Basic Vertical form layout section start -->
            <section id="basic-vertical-layouts">
                <div class="row">
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    حول
                                </h4>
                            </div>
                            <div class="card-body">
                                <form class="form form-vertical" action="{{ aurl('about') }}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">

                                        <div class="col-sm-12">
                                            <label class="form-label" for="basicPost">
                                                العنوان
                                            </label>
                                            <div class="input-group input-group-merge">
                                                <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                                <input
                                                    type="text"
                                                    id="basicPost"
                                                    name="title" value="{{ $data->title }}"
                                                    class="form-control @error('title') is-invalid @enderror" placeholder="title" />
                                            </div>
                                        </div>

                                        <div class="col-sm-12">
                                            <label class="form-label" for="basicPost">
                                                الموضوع
                                            </label>
                                            <div class="input-group input-group-merge">
                                                <span id="basicPost2" class="input-group-text"><i class="ti ti-pencil"></i></span>
                                                <textarea class="form-control" name="des">
                                                    {{ $data->des }}
                                                </textarea>
                                            </div>
                                        </div>
                                        <div class="col-12" style="margin-top: 15px;">
                                            <button type="submit" class="btn btn-primary me-1">
                                                حفظ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Basic Vertical form layout section end -->


        </div>
    </div>

@endsection


