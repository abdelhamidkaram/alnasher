@extends('admin.layouts.app')

@section('content')


    <div class="content-wrapper container-xxl p-0">
        <div class="content-header row">
        </div>
        <div class="content-body">


            <!-- Basic Vertical form layout section start -->
            <section id="basic-vertical-layouts">
                <div class="row">
                    <div class="col-md-12 col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">
                                    الاعدادت
                                </h4>
                            </div>
                            <div class="card-body">
                                <form class="form form-vertical" action="{{ aurl('setting') }}" method="post" enctype="multipart/form-data">
                                    @csrf
                                    <div class="row">

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    Twitter
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-twitter"></i>
                                                    </span>
                                                    <input type="text" name="twitter" value="{{ $data->tiwtter }}"
                                                           class="form-control @error('twitter') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    Facebook
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-facebook"></i>
                                                    </span>
                                                    <input type="text" name="facebook" value="{{ $data->facebook }}"
                                                           class="form-control @error('facebook') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    Instagram
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-instagram"></i>
                                                    </span>
                                                    <input type="text" name="instagram" value="{{ $data->instagram }}"
                                                           class="form-control @error('instagram') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    Snapchat
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-snapchat"></i>
                                                    </span>
                                                    <input type="text" name="snapchat" value="{{ $data->snapchat }}"
                                                           class="form-control @error('snapchat') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    whatsapp
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-whatsapp"></i>
                                                    </span>
                                                    <input type="text" name="whatsapp" value="{{ $data->whatsapp }}"
                                                           class="form-control @error('whatsapp') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    LinkedIn
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-brand-linkedin"></i>
                                                    </span>
                                                    <input type="text" name="linkedin" value="{{ $data->linkedin }}"
                                                           class="form-control @error('linkedin') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    الجوال
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-phone"></i>
                                                    </span>
                                                    <input type="text" name="phone" value="{{ $data->phone }}"
                                                           class="form-control @error('phone') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-3 col-md-3 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    اﻻيميل
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-mail"></i>
                                                    </span>
                                                    <input type="email" name="email" value="{{ $data->email }}"
                                                           class="form-control @error('email') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    اسم الموقع
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-pencil"></i>
                                                    </span>
                                                    <input type="text" name="site_name" value="{{ $data->site_name }}"
                                                           class="form-control @error('site_name') is-invalid @enderror">
                                                </div>
                                            </div>
                                        </div>

                                        <div class="col-lg-6 col-md-6 col-sm-6">
                                            <div class="mb-1">
                                                <label class="form-label" for="first-name-vertical">
                                                    الشعار
                                                </label>
                                                <div class="input-group input-group-merge">
                                                    <span id="basicFullname2" class="input-group-text">
                                                        <i class="ti ti-file"></i>
                                                    </span>
                                                    <input type="file" name="logo" value="{{ $data->logo }}"
                                                           class="form-control @error('logo') is-invalid @enderror">
                                                </div>
                                            </div>
                                            <br/>
                                            @if(\File::exists($data->logo))
                                            <img src="{{ asset($data->logo) }}" width="100">
                                            @endif
                                        </div>


                                        <div class="col-12" style="margin-top: 15px;">
                                            <button type="submit" class="btn btn-primary me-1">
                                                حفظ
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- Basic Vertical form layout section end -->


        </div>
    </div>

@endsection


