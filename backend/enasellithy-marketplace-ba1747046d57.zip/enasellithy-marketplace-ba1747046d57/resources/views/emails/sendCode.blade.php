@component('mail::message')
    <h2>مرحبا بك</h2>

    <p>
        كود التفعيل
        <br/>
        {{ $data }}
    </p>


    <br>

    شكرا,<br>

    منصة الناشر
@endcomponent
