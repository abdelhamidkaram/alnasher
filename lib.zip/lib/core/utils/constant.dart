class AppConstants {
  static String TOKEN = "token";
  static String USER = "user";
  static String ID = "id";

}
