import 'package:alnsher/bloc/route/navigator_args/base_navegator_args.dart';

class SearchArgs extends BaseNavigatorArgs{
  
}