import 'package:alnsher/bloc/route/navigator_args/base_navegator_args.dart';
import 'package:alnsher/model/home_model.dart';

class SinglePostNavigationArgs extends BaseNavigatorArgs{
  final Ad ad ;
  SinglePostNavigationArgs({required this.ad});
}