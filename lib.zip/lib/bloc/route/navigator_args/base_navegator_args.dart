abstract class BaseNavigatorArgs{
  const BaseNavigatorArgs();

}

class NoArgs extends BaseNavigatorArgs{

}