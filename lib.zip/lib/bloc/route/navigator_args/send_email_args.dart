import 'package:alnsher/bloc/route/navigator_args/base_navegator_args.dart';

class SenderEmailSenderArgs extends BaseNavigatorArgs{
  final String email ;
  SenderEmailSenderArgs({required this.email});
}